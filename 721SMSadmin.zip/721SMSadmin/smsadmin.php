<?php
/*
Plugin Name: SMSadmin
Plugin URI: https://example.com/smsadmin
Description: افزونه مدیریت پیامک با امکانات پیشرفته برای وردپرس
Version: 7.2.1
Author: حسین خرمی
Author URI: https://example.com
License: GPL2
Text Domain: smsadmin
Domain Path: /languages
*/

defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

define('SMSADMIN_VERSION', '7.2.1');
define('SMSADMIN_DIR', plugin_dir_path(__FILE__));
define('SMSADMIN_URL', plugin_dir_url(__FILE__));

function smsadmin_load_textdomain() {
    load_plugin_textdomain('smsadmin', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'smsadmin_load_textdomain');

require_once SMSADMIN_DIR . 'includes/functions.php';
require_once SMSADMIN_DIR . 'includes/install.php';
require_once SMSADMIN_DIR . 'includes/dashboard.php';
require_once SMSADMIN_DIR . 'includes/settings.php';
require_once SMSADMIN_DIR . 'includes/api.php';
require_once SMSADMIN_DIR . 'includes/groups.php';
require_once SMSADMIN_DIR . 'includes/send.php';
require_once SMSADMIN_DIR . 'includes/reports.php';
require_once SMSADMIN_DIR . 'includes/support.php';
require_once SMSADMIN_DIR . 'includes/error.php';
require_once SMSADMIN_DIR . 'includes/config.php';
require_once SMSADMIN_DIR . 'includes/logs.php';

function smsadmin_enqueue_assets() {
    wp_enqueue_style('smsadmin-style', SMSADMIN_URL . 'assets/css/style.css', [], SMSADMIN_VERSION);
    wp_enqueue_script('smsadmin-script', SMSADMIN_URL . 'assets/js/script.js', ['jquery'], SMSADMIN_VERSION, true);
    wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '3.9.1', true);
    wp_enqueue_script('datatables', 'https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js', ['jquery'], '1.11.5', true);
    wp_localize_script('smsadmin-script', 'smsAdminAjax', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('smsadmin_nonce')
    ]);
}
add_action('admin_enqueue_scripts', 'smsadmin_enqueue_assets');

function smsadmin_admin_menu() {
    add_menu_page(
        __('SMSadmin', 'smsadmin'),
        __('SMSadmin', 'smsadmin'),
        'manage_options',
        'smsadmin',
        'smsadmin_dashboard_page',
        'dashicons-sms',
        10
    );
    add_submenu_page(
        'smsadmin',
        __('داشبورد', 'smsadmin'),
        __('داشبورد', 'smsadmin'),
        'manage_options',
        'smsadmin',
        'smsadmin_dashboard_page'
    );
    add_submenu_page(
        'smsadmin',
        __('مدیریت پیامک', 'smsadmin'),
        __('مدیریت پیامک', 'smsadmin'),
        'manage_options',
        'smsadmin-settings',
        'smsadmin_settings_page'
    );
    add_submenu_page(
        'smsadmin',
        __('تنظیمات API', 'smsadmin'),
        __('تنظیمات API', 'smsadmin'),
        'manage_options',
        'smsadmin-api',
        'smsadmin_api_page'
    );
    add_submenu_page(
        'smsadmin',
        __('مدیریت گروه‌ها', 'smsadmin'),
        __('مدیریت گروه‌ها', 'smsadmin'),
        'manage_options',
        'smsadmin-groups',
        'smsadmin_groups_page'
    );
    add_submenu_page(
        'smsadmin',
        __('ارسال پیامک', 'smsadmin'),
        __('ارسال پیامک', 'smsadmin'),
        'manage_options',
        'smsadmin-send',
        'smsadmin_send_page'
    );
    add_submenu_page(
        'smsadmin',
        __('گزارش‌گیری', 'smsadmin'),
        __('گزارش‌گیری', 'smsadmin'),
        'manage_options',
        'smsadmin-reports',
        'smsadmin_reports_page'
    );
    add_submenu_page(
        'smsadmin',
        __('پشتیبانی', 'smsadmin'),
        __('پشتیبانی', 'smsadmin'),
        'manage_options',
        'smsadmin-support',
        'smsadmin_support_page'
    );
    add_submenu_page(
        'smsadmin',
        __('گزارش خطا', 'smsadmin'),
        __('گزارش خطا', 'smsadmin'),
        'manage_options',
        'smsadmin-error',
        'smsadmin_error_page'
    );
    add_submenu_page(
        'smsadmin',
        __('پیکربندی و فعال‌سازی', 'smsadmin'),
        __('پیکربندی و فعال‌سازی', 'smsadmin'),
        'manage_options',
        'smsadmin-config',
        'smsadmin_config_page'
    );
}
add_action('admin_menu', 'smsadmin_admin_menu');

register_activation_hook(__FILE__, 'smsadmin_install');
register_deactivation_hook(__FILE__, 'smsadmin_deactivate');

function smsadmin_deactivate() {
    wp_clear_scheduled_hook('smsadmin_scheduled_send');
}