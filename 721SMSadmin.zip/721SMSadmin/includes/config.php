<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_config_page() {
    global $wpdb;
    if (isset($_POST['save_config'])) {
        check_admin_referer('smsadmin_config_nonce');
        $config = [
            'theme_color' => sanitize_hex_color($_POST['theme_color']),
            'font_size' => absint($_POST['font_size']),
            'admin_email' => sanitize_email($_POST['admin_email']),
            'admin_phone' => sanitize_text_field($_POST['admin_phone']),
            'api_user' => sanitize_text_field($_POST['api_user']),
            'api_pass' => wp_hash_password($_POST['api_pass'])
        ];
        update_option('smsadmin_setup', $config);
        echo '<div class="updated"><p>' . __('تنظیمات ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['save_user'])) {
        check_admin_referer('smsadmin_config_nonce');
        $access = isset($_POST['access']) ? array_map('sanitize_text_field', $_POST['access']) : [];
        $user = [
            'username' => sanitize_text_field($_POST['username']),
            'role' => sanitize_text_field($_POST['role']),
            'access' => json_encode($access),
            'created_at' => current_time('mysql')
        ];
        $wpdb->insert($wpdb->prefix . 'sms_users', $user);
        echo '<div class="updated"><p>' . __('اکانت ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['delete_user'])) {
        check_admin_referer('smsadmin_config_nonce');
        $user_id = absint($_POST['delete_user']);
        $wpdb->delete($wpdb->prefix . 'sms_users', ['id' => $user_id]);
        echo '<div class="updated"><p>' . __('اکانت حذف شد.', 'smsadmin') . '</p></div>';
    }

    $config = get_option('smsadmin_setup', []);
    $users = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_users ORDER BY created_at DESC");
    $credit = smsadmin_get_api_credit();
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('پیکربندی و فعال‌سازی', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px; text-align: right;">
            <p style="font-family: Tahoma; font-size: 16px; color: #E74C3C; text-shadow: 1px 1px 2px rgba(0,0,0,0.2);">
                <?php _e('برای فعال‌سازی اکانت، مدارک هویتی را به شماره <strong>09128855816</strong> از طریق واتساپ ارسال کنید.', 'smsadmin'); ?>
            </p>
            <a href="https://wa.me/989128855816?text=<?php echo urlencode(__('ارسال مدارک هویتی برای فعال‌سازی افزونه SMSadmin', 'smsadmin')); ?>" 
               target="_blank" 
               class="button button-primary" 
               style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                <?php _e('ارسال مدارک', 'smsadmin'); ?>
            </a>
        </div>
        <div class="smsadmin-tabs">
            <ul class="nav-tab-wrapper">
                <li><a href="#tab-config" class="nav-tab nav-tab-active"><?php _e('تنظیمات اولیه', 'smsadmin'); ?></a></li>
                <li><a href="#tab-api" class="nav-tab"><?php _e('تنظیمات API', 'smsadmin'); ?></a></li>
                <li><a href="#tab-users" class="nav-tab"><?php _e('مدیریت کاربران', 'smsadmin'); ?></a></li>
            </ul>
            <div id="tab-config" class="tab-content">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('تنظیمات اولیه', 'smsadmin'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_config_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('رنگ قالب', 'smsadmin'); ?></label></th>
                                <td><input type="color" name="theme_color" value="<?php echo esc_attr($config['theme_color'] ?? '#E6F3FA'); ?>" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('اندازه فونت (px)', 'smsadmin'); ?></label></th>
                                <td><input type="number" name="font_size" value="<?php echo esc_attr($config['font_size'] ?? 14); ?>" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ایمیل مدیر', 'smsadmin'); ?></label></th>
                                <td><input type="email" name="admin_email" value="<?php echo esc_attr($config['admin_email'] ?? ''); ?>" style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('شماره مدیر', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="admin_phone" value="<?php echo esc_attr($config['admin_phone'] ?? ''); ?>" style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                        </table>
                        <button type="submit" name="save_config" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ذخیره تنظیمات', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-api" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('تنظیمات API', 'smsadmin'); ?></h3>
                    <p style="font-family: Tahoma;"><?php printf(__('مانده اعتبار: %s', 'smsadmin'), $credit ?: __('بدون API', 'smsadmin')); ?></p>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_config_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('نام کاربری API', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="api_user" value="<?php echo esc_attr($config['api_user'] ?? ''); ?>" style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('رمز عبور API', 'smsadmin'); ?></label></th>
                                <td><input type="password" name="api_pass" style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                        </table>
                        <button type="submit" name="save_config" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ذخیره تنظیمات', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-users" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('افزودن کاربر', 'smsadmin'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_config_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('نام کاربری', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="username" required style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('نقش', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="role" style="font-family: Tahoma;">
                                        <option value="admin"><?php _e('مدیر', 'smsadmin'); ?></option>
                                        <option value="editor"><?php _e('ویرایشگر', 'smsadmin'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('دسترسی‌ها', 'smsadmin'); ?></label></th>
                                <td>
                                    <label><input type="checkbox" name="access[]" value="dashboard"> <?php _e('داشبورد', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="settings"> <?php _e('مدیریت پیامک', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="api"> <?php _e('تنظیمات API', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="groups"> <?php _e('گروه‌بندی', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="send"> <?php _e('ارسال پیامک', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="reports"> <?php _e('گزارش‌گیری', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="support"> <?php _e('پشتیبانی', 'smsadmin'); ?></label><br>
                                    <label><input type="checkbox" name="access[]" value="error"> <?php _e('گزارش خطا', 'smsadmin'); ?></label>
                                </td>
                            </tr>
                        </table>
                        <button type="submit" name="save_user" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ذخیره کاربر', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('کاربران موجود', 'smsadmin'); ?></h3>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('نام کاربری', 'smsadmin'); ?></th>
                                <th><?php _e('نقش', 'smsadmin'); ?></th>
                                <th><?php _e('دسترسی‌ها', 'smsadmin'); ?></th>
                                <th><?php _e('تاریخ ایجاد', 'smsadmin'); ?></th>
                                <th><?php _e('عملیات', 'smsadmin'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo esc_html($user->username); ?></td>
                                    <td><?php echo esc_html($user->role); ?></td>
                                    <td><?php echo esc_html(implode(', ', json_decode($user->access, true))); ?></td>
                                    <td><?php echo esc_html($user->created_at); ?></td>
                                    <td>
                                        <form method="post" style="display: inline;">
                                            <?php wp_nonce_field('smsadmin_config_nonce'); ?>
                                            <input type="hidden" name="delete_user" value="<?php echo esc_attr($user->id); ?>">
                                            <button type="submit" class="button" 
                                                style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                                <?php _e('حذف', 'smsadmin'); ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('.nav-tab').on('click', function(e) {
                    e.preventDefault();
                    $('.nav-tab').removeClass('nav-tab-active');
                    $(this).addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $($(this).attr('href')).show();
                });
            });
        </script>
    </div>
    <?php
}
?>