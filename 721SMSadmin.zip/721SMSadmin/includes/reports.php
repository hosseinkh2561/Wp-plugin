<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_reports_page() {
    global $wpdb;
    $filters = [
        'from_date' => isset($_POST['from_date']) ? sanitize_text_field($_POST['from_date']) : '',
        'to_date' => isset($_POST['to_date']) ? sanitize_text_field($_POST['to_date']) : '',
        'type' => isset($_POST['type']) ? sanitize_text_field($_POST['type']) : '',
        'status' => isset($_POST['status']) ? sanitize_text_field($_POST['status']) : ''
    ];
    $where = [];
    if ($filters['from_date']) {
        $where[] = $wpdb->prepare("date >= %s", $filters['from_date']);
    }
    if ($filters['to_date']) {
        $where[] = $wpdb->prepare("date <= %s", $filters['to_date']);
    }
    if ($filters['type']) {
        $where[] = $wpdb->prepare("type = %s", $filters['type']);
    }
    if ($filters['status']) {
        $where[] = $wpdb->prepare("status = %s", $filters['status']);
    }
    $where_clause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';
    $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_logs $where_clause ORDER BY date DESC LIMIT 100");
    
    if (isset($_POST['export_csv'])) {
        check_admin_referer('smsadmin_reports_nonce');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=smsadmin_report_' . date('Ymd') . '.csv');
        $output = fopen('php://output', 'w');
        fputs($output, "\xEF\xBB\xBF"); // UTF-8 BOM
        fputcsv($output, [
            __('تاریخ', 'smsadmin'),
            __('نوع پیامک', 'smsadmin'),
            __('شماره مقصد', 'smsadmin'),
            __('متن پیام', 'smsadmin'),
            __('وضعیت', 'smsadmin')
        ], ';');
        foreach ($logs as $log) {
            fputcsv($output, [
                $log->date,
                $log->type,
                $log->phone,
                $log->message,
                $log->status
            ], ';');
        }
        fclose($output);
        exit;
    }
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('گزارش‌گیری', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('فیلتر گزارش‌ها', 'smsadmin'); ?></h3>
            <form method="post">
                <?php wp_nonce_field('smsadmin_reports_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('از تاریخ', 'smsadmin'); ?></label></th>
                        <td><input type="date" name="from_date" value="<?php echo esc_attr($filters['from_date']); ?>" style="font-family: Tahoma;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('تا تاریخ', 'smsadmin'); ?></label></th>
                        <td><input type="date" name="to_date" value="<?php echo esc_attr($filters['to_date']); ?>" style="font-family: Tahoma;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('نوع پیامک', 'smsadmin'); ?></label></th>
                        <td>
                            <select name="type" style="font-family: Tahoma;">
                                <option value=""><?php _e('همه', 'smsadmin'); ?></option>
                                <option value="ورود" <?php selected($filters['type'], 'ورود'); ?>><?php _e('ورود', 'smsadmin'); ?></option>
                                <option value="خرید" <?php selected($filters['type'], 'خرید'); ?>><?php _e('خرید', 'smsadmin'); ?></option>
                                <option value="خبرنامه" <?php selected($filters['type'], 'خبرنامه'); ?>><?php _e('خبرنامه', 'smsadmin'); ?></option>
                                <option value="گروهی" <?php selected($filters['type'], 'گروهی'); ?>><?php _e('گروهی', 'smsadmin'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('وضعیت', 'smsadmin'); ?></label></th>
                        <td>
                            <select name="status" style="font-family: Tahoma;">
                                <option value=""><?php _e('همه', 'smsadmin'); ?></option>
                                <option value="ارسال‌شده" <?php selected($filters['status'], 'ارسال‌شده'); ?>><?php _e('ارسال‌شده', 'smsadmin'); ?></option>
                                <option value="ناموفق" <?php selected($filters['status'], 'ناموفق'); ?>><?php _e('ناموفق', 'smsadmin'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <button type="submit" class="button button-primary" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('فیلتر', 'smsadmin'); ?>
                </button>
                <button type="submit" name="export_csv" class="button" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('خروجی CSV', 'smsadmin'); ?>
                </button>
            </form>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('گزارش‌های ارسالی', 'smsadmin'); ?></h3>
            <canvas id="reportChart" style="max-height: 300px;"></canvas>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('تاریخ', 'smsadmin'); ?></th>
                        <th><?php _e('نوع پیامک', 'smsadmin'); ?></th>
                        <th><?php _e('شماره مقصد', 'smsadmin'); ?></th>
                        <th><?php _e('متن پیام', 'smsadmin'); ?></th>
                        <th><?php _e('وضعیت', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->date); ?></td>
                            <td><?php echo esc_html($log->type); ?></td>
                            <td><?php echo esc_html($log->phone); ?></td>
                            <td><?php echo esc_html(wp_trim_words($log->message, 10)); ?></td>
                            <td><?php echo esc_html($log->status); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <script>
            jQuery(document).ready(function($) {
                var ctx = document.getElementById('reportChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: ['<?php _e('ارسال‌شده', 'smsadmin'); ?>', '<?php _e('ناموفق', 'smsadmin'); ?>'],
                        datasets: [{
                            label: '<?php _e('وضعیت ارسال', 'smsadmin'); ?>',
                            data: [
                                <?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'ارسال‌شده'"); ?>,
                                <?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'ناموفق'"); ?>
                            ],
                            backgroundColor: ['#4A90E2', '#E74C3C']
                        }]
                    },
                    options: {
                        scales: {
                            y: { beginAtZero: true }
                        }
                    }
                });
            });
        </script>
    </div>
    <?php
}
?>