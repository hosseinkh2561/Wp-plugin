<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_settings_page() {
    if (isset($_POST['save_settings'])) {
        check_admin_referer('smsadmin_settings_nonce');
        $settings = [
            'send_login' => isset($_POST['send_login']) ? '1' : '0',
            'send_password' => isset($_POST['send_password']) ? '1' : '0',
            'send_order' => isset($_POST['send_order']) ? '1' : '0',
            'send_newsletter' => isset($_POST['send_newsletter']) ? '1' : '0',
            'send_register' => isset($_POST['send_register']) ? '1' : '0',
            'send_order_status' => isset($_POST['send_order_status']) ? '1' : '0',
            'daily_limit' => absint($_POST['daily_limit']),
            'default_template' => absint($_POST['default_template']),
            'api_priority' => absint($_POST['api_priority']),
            'schedule_type' => sanitize_text_field($_POST['schedule_type'])
        ];
        update_option('smsadmin_settings', $settings);
        echo '<div class="updated"><p>' . __('تنظیمات ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['save_template'])) {
        check_admin_referer('smsadmin_settings_nonce');
        $templates = get_option('smsadmin_templates', []);
        $template_id = isset($_POST['template_id']) ? absint($_POST['template_id']) : uniqid();
        $templates[$template_id] = [
            'title' => sanitize_text_field($_POST['template_title']),
            'content' => wp_kses_post($_POST['template_content']),
            'vars' => sanitize_text_field($_POST['template_vars'])
        ];
        update_option('smsadmin_templates', $templates);
        echo '<div class="updated"><p>' . __('قالب ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['delete_template'])) {
        check_admin_referer('smsadmin_settings_nonce');
        $template_id = sanitize_text_field($_POST['delete_template']);
        $templates = get_option('smsadmin_templates', []);
        unset($templates[$template_id]);
        update_option('smsadmin_templates', $templates);
        echo '<div class="updated"><p>' . __('قالب حذف شد.', 'smsadmin') . '</p></div>';
    }

    $settings = get_option('smsadmin_settings', []);
    $templates = get_option('smsadmin_templates', []);
    $apis = get_option('smsadmin_api_settings', []);
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('مدیریت پیامک', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-tabs">
            <ul class="nav-tab-wrapper">
                <li><a href="#tab-settings" class="nav-tab nav-tab-active"><?php _e('تنظیمات ارسال پیامک', 'smsadmin'); ?></a></li>
                <li><a href="#tab-templates" class="nav-tab"><?php _e('مدیریت قالب‌های متنی', 'smsadmin'); ?></a></li>
                <li><a href="#tab-events" class="nav-tab"><?php _e('رویدادهای سفارشی', 'smsadmin'); ?></a></li>
            </ul>
            <div id="tab-settings" class="tab-content">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('تنظیمات ارسال پیامک', 'smsadmin'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_settings_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ارسال پیامک ورود', 'smsadmin'); ?></label></th>
                                <td><input type="checkbox" name="send_login" <?php checked($settings['send_login'], '1'); ?>></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ارسال پیامک بازیابی رمز', 'smsadmin'); ?></label></th>
                                <td><input type="checkbox" name="send_password" <?php checked($settings['send_password'], '1'); ?>></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ارسال پیامک خرید', 'smsadmin'); ?></label></th>
                                <td><input type="checkbox" name="send_order" <?php checked($settings['send_order'], '1'); ?>></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ارسال پیامک خبرنامه', 'smsadmin'); ?></label></th>
                                <td><input type="checkbox" name="send_newsletter" <?php checked($settings['send_newsletter'], '1'); ?>></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ارسال پیامک ثبت‌نام', 'smsadmin'); ?></label></th>
                                <td><input type="checkbox" name="send_register" <?php checked($settings['send_register'], '1'); ?>></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('ارسال پیامک تغییر وضعیت سفارش', 'smsadmin'); ?></label></th>
                                <td><input type="checkbox" name="send_order_status" <?php checked($settings['send_order_status'], '1'); ?>></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('محدودیت روزانه ارسال', 'smsadmin'); ?></label></th>
                                <td><input type="number" name="daily_limit" value="<?php echo esc_attr($settings['daily_limit'] ?? '1000'); ?>" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('قالب پیش‌فرض', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="default_template" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون قالب', 'smsadmin'); ?></option>
                                        <?php foreach ($templates as $id => $template): ?>
                                            <option value="<?php echo esc_attr($id); ?>" <?php selected($settings['default_template'], $id); ?>>
                                                <?php echo esc_html($template['title']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('اولویت API', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="api_priority" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون اولویت', 'smsadmin'); ?></option>
                                        <?php foreach ($apis as $id => $api): ?>
                                            <option value="<?php echo esc_attr($id); ?>" <?php selected($settings['api_priority'], $id); ?>>
                                                <?php echo esc_html($api['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('نوع زمان‌بندی', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="schedule_type" style="font-family: Tahoma;">
                                        <option value="" <?php selected($settings['schedule_type'], ''); ?>><?php _e('بدون زمان‌بندی', 'smsadmin'); ?></option>
                                        <option value="daily" <?php selected($settings['schedule_type'], 'daily'); ?>><?php _e('روزانه', 'smsadmin'); ?></option>
                                        <option value="weekly" <?php selected($settings['schedule_type'], 'weekly'); ?>><?php _e('هفتگی', 'smsadmin'); ?></option>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        <button type="submit" name="save_settings" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ذخیره تنظیمات', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-templates" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('مدیریت قالب‌های متنی', 'smsadmin'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_settings_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('عنوان قالب', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="template_title" required style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('محتوای قالب', 'smsadmin'); ?></label></th>
                                <td><textarea name="template_content" required style="font-family: Tahoma; width: 100%; height: 100px;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('متغیرهای اضافی', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="template_vars" placeholder="<?php _e('مثال: {نام}، {تاریخ}', 'smsadmin'); ?>" style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                        </table>
                        <button type="submit" name="save_template" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ذخیره قالب', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('قالب‌های موجود', 'smsadmin'); ?></h3>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('عنوان', 'smsadmin'); ?></th>
                                <th><?php _e('محتوا', 'smsadmin'); ?></th>
                                <th><?php _e('متغیرها', 'smsadmin'); ?></th>
                                <th><?php _e('عملیات', 'smsadmin'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($templates as $id => $template): ?>
                                <tr>
                                    <td><?php echo esc_html($template['title']); ?></td>
                                    <td><?php echo esc_html(wp_trim_words($template['content'], 10)); ?></td>
                                    <td><?php echo esc_html($template['vars']); ?></td>
                                    <td>
                                        <button class="button edit-template" 
                                            data-id="<?php echo esc_attr($id); ?>" 
                                            data-title="<?php echo esc_attr($template['title']); ?>" 
                                            data-content="<?php echo esc_attr($template['content']); ?>" 
                                            data-vars="<?php echo esc_attr($template['vars']); ?>" 
                                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                            <?php _e('ویرایش', 'smsadmin'); ?>
                                        </button>
                                        <form method="post" style="display: inline;">
                                            <?php wp_nonce_field('smsadmin_settings_nonce'); ?>
                                            <input type="hidden" name="delete_template" value="<?php echo esc_attr($id); ?>">
                                            <button type="submit" class="button" 
                                                style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                                <?php _e('حذف', 'smsadmin'); ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="tab-events" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('رویدادهای سفارشی', 'smsadmin'); ?></h3>
                    <p style="font-family: Tahoma;"><?php _e('در حال توسعه: امکان افزودن رویدادهای سفارشی برای ارسال پیامک.', 'smsadmin'); ?></p>
                </div>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('.nav-tab').on('click', function(e) {
                    e.preventDefault();
                    $('.nav-tab').removeClass('nav-tab-active');
                    $(this).addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $($(this).attr('href')).show();
                });
                $('.edit-template').on('click', function() {
                    var data = $(this).data();
                    $('input[name="template_title"]').val(data.title);
                    $('textarea[name="template_content"]').val(data.content);
                    $('input[name="template_vars"]').val(data.vars);
                    $('<input>').attr({
                        type: 'hidden',
                        name: 'template_id',
                        value: data.id
                    }).appendTo('form');
                });
            });
        </script>
    </div>
    <?php
}

add_action('wp_login', function($user_login, $user) {
    $settings = get_option('smsadmin_settings', []);
    if ($settings['send_login'] !== '1') return;
    $templates = get_option('smsadmin_templates', []);
    $template = $templates['login']['content'] ?? 'ورود به حساب کاربری در تاریخ {تاریخ} انجام شد.';
    $message = str_replace('{تاریخ}', current_time('Y-m-d H:i:s'), $template);
    $phone = get_user_meta($user->ID, 'billing_phone', true);
    if ($phone) {
        smsadmin_send_sms([$phone], $message, $settings['api_priority'], 'ورود');
    }
}, 10, 2);

add_action('woocommerce_order_status_changed', function($order_id, $old_status, $new_status) {
    $settings = get_option('smsadmin_settings', []);
    if ($settings['send_order_status'] !== '1') return;
    $order = wc_get_order($order_id);
    $phone = $order->get_billing_phone();
    if (!$phone) return;
    $templates = get_option('smsadmin_templates', []);
    $template = $templates['order']['content'] ?? 'سفارش #{سفارش} به وضعیت {وضعیت} تغییر یافت.';
    $message = str_replace(
        ['{سفارش}', '{وضعیت}'],
        [$order_id, $new_status],
        $template
    );
    smsadmin_send_sms([$phone], $message, $settings['api_priority'], 'تغییر وضعیت');
}, 10, 3);