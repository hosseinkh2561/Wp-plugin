<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_support_page() {
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('پشتیبانی', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); text-align: right;">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('درباره افزونه', 'smsadmin'); ?></h3>
            <p style="font-family: Tahoma;"><?php _e('کلیه تنظیمات، کدنویسی و طراحی افزونه SMSadmin توسط <strong>حسین خرمی</strong> انجام شده است. این افزونه در ۷ نسخه تست و بررسی شده و نسخه 7.2.1 به‌عنوان نسخه نهایی ارائه گردیده است.', 'smsadmin'); ?></p>
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('نسخه‌های تکمیل‌شده', 'smsadmin'); ?></h3>
            <ul style="font-family: Tahoma;">
                <li><?php _e('۱.۱.۰ - طراحی اولیه افزونه', 'smsadmin'); ?></li>
                <li><?php _e('۱.۳.۱ - افزودن منوهای داشبورد', 'smsadmin'); ?></li>
                <li><?php _e('۲.۰.۱ - اضافه شدن خبرنامه و ارسال‌های گروهی', 'smsadmin'); ?></li>
                <li><?php _e('۳.۱.۵ - تکمیل ارسال‌ها برای فروشگاه', 'smsadmin'); ?></li>
                <li><?php _e('۴.۳.۱ - تنظیمات API مرجع', 'smsadmin'); ?></li>
                <li><?php _e('۵.۳ - تکمیل ساختار کلی', 'smsadmin'); ?></li>
                <li><?php _e('۶.۱.۳ - سفارشی‌سازی و تکمیل', 'smsadmin'); ?></li>
                <li><?php _e('۷.۲.۱ - ارائه افزونه نهایی با امکانات پیشرفته', 'smsadmin'); ?></li>
            </ul>
            <p style="font-family: Tahoma;"><?php _e('افزونه SMSadmin با تلاش و هماهنگی گسترده تیم توسعه به رهبری <strong>حسین خرمی</strong> طراحی و پیاده‌سازی شده است. برای پشتیبانی، با شماره <strong>09185696702</strong> از طریق واتساپ در ارتباط باشید.', 'smsadmin'); ?></p>
            <a href="https://wa.me/989185696702?text=<?php echo urlencode(__('درخواست پشتیبانی افزونه SMSadmin', 'smsadmin')); ?>" 
               target="_blank" 
               class="button button-primary" 
               style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                <?php _e('گزارش مشکل', 'smsadmin'); ?>
            </a>
        </div>
    </div>
    <?php
}
?>