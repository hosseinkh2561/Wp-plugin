<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_get_api_credit() {
    $apis = get_option('smsadmin_api_settings', []);
    if (empty($apis)) return false;
    $api = reset($apis);
    try {
        $client = new SoapClient($api['url'], ['exceptions' => true]);
        $response = $client->getcredit([
            'user' => $api['user'],
            'pass' => $api['pass']
        ]);
        return $response->credit;
    } catch (Exception $e) {
        smsadmin_log_api_error($e->getMessage());
        return false;
    }
}

function smsadmin_log_api_error($message) {
    $log_dir = SMSADMIN_DIR . 'logs/api_errors/';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    $log_file = $log_dir . 'error_log_' . date('Ymd') . '.txt';
    $log_message = sprintf(
        "[%s] %s\n",
        current_time('mysql'),
        $message
    );
    file_put_contents($log_file, $log_message, FILE_APPEND);
}

function smsadmin_send_sms($numbers, $message, $api_id, $type = 'تکی') {
    global $wpdb;
    $apis = get_option('smsadmin_api_settings', []);
    if (!isset($apis[$api_id])) return false;
    $api = $apis[$api_id];
    try {
        $client = new SoapClient($api['url'], ['exceptions' => true]);
        $response = $client->sendmultiple([
            'user' => $api['user'],
            'pass' => $api['pass'],
            'to' => $numbers,
            'from' => [$api['from']],
            'text' => [$message]
        ]);
        $status = $response->id ? 'ارسال‌شده' : 'ناموفق';
        foreach ($numbers as $number) {
            $wpdb->insert($wpdb->prefix . 'sms_logs', [
                'date' => current_time('mysql'),
                'type' => $type,
                'phone' => $number,
                'message' => $message,
                'status' => $status
            ]);
        }
        return true;
    } catch (Exception $e) {
        smsadmin_log_api_error($e->getMessage());
        return false;
    }
}