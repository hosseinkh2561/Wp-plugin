<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_dashboard_page() {
    global $wpdb;
    $sent_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'ارسال‌شده'");
    $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_logs ORDER BY date DESC LIMIT 5");
    $credit = smsadmin_get_api_credit();
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('SMSadmin - داشبورد', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('آمار پیامک‌ها', 'smsadmin'); ?></h3>
            <p style="font-family: Tahoma;"><?php printf(__('مانده اعتبار: %s', 'smsadmin'), $credit ?: __('بدون API', 'smsadmin')); ?></p>
            <p style="font-family: Tahoma;"><?php printf(__('پیامک‌های ارسالی: %d', 'smsadmin'), $sent_count); ?></p>
            <canvas id="smsChart" style="max-height: 300px;"></canvas>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('گزارش‌های اخیر', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('تاریخ', 'smsadmin'); ?></th>
                        <th><?php _e('نوع پیامک', 'smsadmin'); ?></th>
                        <th><?php _e('شماره مقصد', 'smsadmin'); ?></th>
                        <th><?php _e('وضعیت', 'smsadmin'); ?></th>
                        <th><?php _e('عملیات', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo esc_html($log->date); ?></td>
                            <td><?php echo esc_html($log->type); ?></td>
                            <td><?php echo esc_html($log->phone); ?></td>
                            <td><?php echo esc_html($log->status); ?></td>
                            <td>
                                <button class="button view-log" 
                                    data-id="<?php echo esc_attr($log->id); ?>" 
                                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                    <?php _e('مشاهده', 'smsadmin'); ?>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <script>
            jQuery(document).ready(function($) {
                var ctx = document.getElementById('smsChart').getContext('2d');
                new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: ['<?php _e('ارسال‌شده', 'smsadmin'); ?>', '<?php _e('ناموفق', 'smsadmin'); ?>'],
                        datasets: [{
                            data: [
                                <?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'ارسال‌شده'"); ?>,
                                <?php echo $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'ناموفق'"); ?>
                            ],
                            backgroundColor: ['#4A90E2', '#E74C3C']
                        }]
                    },
                    options: {
                        responsive: true
                    }
                });
            });
        </script>
    </div>
    <?php
}