<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_error_page() {
    global $wpdb;
    if (isset($_POST['report_error'])) {
        check_admin_referer('smsadmin_error_nonce');
        $section = sanitize_text_field($_POST['error_section']);
        $description = wp_kses_post($_POST['error_description']);
        $wpdb->insert($wpdb->prefix . 'sms_errors', [
            'date' => current_time('mysql'),
            'section' => $section,
            'description' => $description,
            'status' => 'ثبت‌شده'
        ]);
        $error_id = $wpdb->insert_id;
        $whatsapp_url = sprintf(
            'https://wa.me/989185696702?text=%s',
            urlencode(sprintf(__('گزارش خطا #%d از افزونه SMSadmin در بخش %s: %s', 'smsadmin'), $error_id, $section, $description))
        );
        echo '<div class="updated"><p>' . sprintf(
            __('گزارش خطا ثبت شد. برای ارسال به پشتیبانی، <a href="%s" target="_blank">اینجا کلیک کنید</a>.', 'smsadmin'),
            esc_url($whatsapp_url)
        ) . '</p></div>';
    }

    if (isset($_POST['delete_error'])) {
        check_admin_referer('smsadmin_error_nonce');
        $error_id = absint($_POST['delete_error']);
        $wpdb->delete($wpdb->prefix . 'sms_errors', ['id' => $error_id]);
        echo '<div class="updated"><p>' . __('خطا حذف شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['edit_error'])) {
        check_admin_referer('smsadmin_error_nonce');
        $error_id = absint($_POST['edit_error']);
        $description = wp_kses_post($_POST['edit_description']);
        $wpdb->update(
            $wpdb->prefix . 'sms_errors',
            ['description' => $description],
            ['id' => $error_id]
        );
        echo '<div class="updated"><p>' . __('خطا ویرایش شد.', 'smsadmin') . '</p></div>';
    }

    $errors = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_errors ORDER BY date DESC LIMIT 5");
    $api_error_dir = plugin_dir_path(__FILE__) . '../logs/api_errors/';
    $api_errors = glob($api_error_dir . 'error_log_*.txt');
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('گزارش خطا', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('ثبت گزارش خطا', 'smsadmin'); ?></h3>
            <form method="post">
                <?php wp_nonce_field('smsadmin_error_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('بخش خطا', 'smsadmin'); ?></label></th>
                        <td><input type="text" name="error_section" required style="font-family: Tahoma; width: 100%;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('توضیحات', 'smsadmin'); ?></label></th>
                        <td><textarea name="error_description" required style="font-family: Tahoma; width: 100%; height: 100px;"></textarea></td>
                    </tr>
                </table>
                <button type="submit" name="report_error" class="button button-primary" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('ارسال گزارش', 'smsadmin'); ?>
                </button>
            </form>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('گزارش‌های ثبت‌شده', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('تاریخ', 'smsadmin'); ?></th>
                        <th><?php _e('بخش', 'smsadmin'); ?></th>
                        <th><?php _e('توضیحات', 'smsadmin'); ?></th>
                        <th><?php _e('عملیات', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($errors as $error): ?>
                        <tr>
                            <td><?php echo esc_html($error->date); ?></td>
                            <td><?php echo esc_html($error->section); ?></td>
                            <td><?php echo esc_html(wp_trim_words($error->description, 10)); ?></td>
                            <td>
                                <button class="button view-error" 
                                    data-id="<?php echo esc_attr($error->id); ?>" 
                                    data-description="<?php echo esc_attr($error->description); ?>" 
                                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                    <?php _e('مشاهده', 'smsadmin'); ?>
                                </button>
                                <button class="button edit-error" 
                                    data-id="<?php echo esc_attr($error->id); ?>" 
                                    data-description="<?php echo esc_attr($error->description); ?>" 
                                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                    <?php _e('ویرایش', 'smsadmin'); ?>
                                </button>
                                <form method="post" style="display: inline;">
                                    <?php wp_nonce_field('smsadmin_error_nonce'); ?>
                                    <input type="hidden" name="delete_error" value="<?php echo esc_attr($error->id); ?>">
                                    <button type="submit" class="button" 
                                        style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                        <?php _e('حذف', 'smsadmin'); ?>
                                    </button>
                                </form>
                                <a href="https://wa.me/989185696702?text=<?php echo urlencode(sprintf(__('گزارش خطا #%d از افزونه SMSadmin در بخش %s: %s', 'smsadmin'), $error->id, $error->section, $error->description)); ?>" 
                                   target="_blank" 
                                   class="button" 
                                   style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                    <?php _e('ارسال به واتساپ', 'smsadmin'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('خطاهای API', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('فایل', 'smsadmin'); ?></th>
                        <th><?php _e('تاریخ', 'smsadmin'); ?></th>
                        <th><?php _e('عملیات', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($api_errors as $file): ?>
                        <tr>
                            <td><?php echo esc_html(basename($file)); ?></td>
                            <td><?php echo esc_html(date('Y-m-d', filemtime($file))); ?></td>
                            <td>
                                <button class="button view-api-error" 
                                    data-file="<?php echo esc_attr(basename($file)); ?>" 
                                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                    <?php _e('مشاهده', 'smsadmin'); ?>
                                </button>
                                <form method="post" style="display: inline;">
                                    <?php wp_nonce_field('smsadmin_error_nonce'); ?>
                                    <input type="hidden" name="delete_api_error" value="<?php echo esc_attr(basename($file)); ?>">
                                    <button type="submit" class="button" 
                                        style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                        <?php _e('حذف', 'smsadmin'); ?>
                                    </button>
                                </form>
                                <a href="https://wa.me/989185696702?text=<?php echo urlencode(sprintf(__('گزارش خطای API از افزونه SMSadmin: %s', 'smsadmin'), basename($file))); ?>" 
                                   target="_blank" 
                                   class="button" 
                                   style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                    <?php _e('ارسال به واتساپ', 'smsadmin'); ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('.view-error').on('click', function() {
                    alert('<?php _e('توضیحات خطا:', 'smsadmin'); ?>\n' + $(this).data('description'));
                });
                $('.edit-error').on('click', function() {
                    var id = $(this).data('id');
                    var description = $(this).data('description');
                    $('input[name="error_section"]').val($(this).closest('tr').find('td:nth-child(2)').text());
                    $('textarea[name="error_description"]').val(description);
                    $('<input>').attr({
                        type: 'hidden',
                        name: 'edit_error',
                        value: id
                    }).appendTo('form');
                });
                $('.view-api-error').on('click', function() {
                    var file = $(this).data('file');
                    $.post(smsAdminAjax.ajaxurl, {
                        action: 'smsadmin_view_api_error',
                        nonce: smsAdminAjax.nonce,
                        file: file
                    }, function(response) {
                        alert('<?php _e('محتوای خطا:', 'smsadmin'); ?>\n' + response.data);
                    });
                });
            });
        </script>
    </div>
    <?php
}

add_action('wp_ajax_smsadmin_view_api_error', function() {
    check_ajax_referer('smsadmin_nonce', 'nonce');
    $file = sanitize_file_name($_POST['file']);
    $path = plugin_dir_path(__FILE__) . '../logs/api_errors/' . $file;
    if (file_exists($path)) {
        $content = file_get_contents($path);
        wp_send_json_success($content);
    } else {
        wp_send_json_error(__('فایل یافت نشد.', 'smsadmin'));
    }
});
?>