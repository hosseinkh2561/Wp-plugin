<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_api_page() {
    if (isset($_POST['save_api'])) {
        check_admin_referer('smsadmin_api_nonce');
        $apis = get_option('smsadmin_api_settings', []);
        $api_id = isset($_POST['api_id']) ? absint($_POST['api_id']) : uniqid();
        $apis[$api_id] = [
            'name' => sanitize_text_field($_POST['api_name']),
            'user' => sanitize_text_field($_POST['api_user']),
            'pass' => wp_hash_password($_POST['api_pass']),
            'from' => sanitize_text_field($_POST['api_from']),
            'url' => esc_url_raw($_POST['api_url'])
        ];
        update_option('smsadmin_api_settings', $apis);
        echo '<div class="updated"><p>' . __('API ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['delete_api'])) {
        check_admin_referer('smsadmin_api_nonce');
        $api_id = absint($_POST['delete_api']);
        $apis = get_option('smsadmin_api_settings', []);
        unset($apis[$api_id]);
        update_option('smsadmin_api_settings', $apis);
        echo '<div class="updated"><p>' . __('API حذف شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['test_api'])) {
        check_admin_referer('smsadmin_api_nonce');
        $api_id = absint($_POST['test_api']);
        $apis = get_option('smsadmin_api_settings', []);
        if (isset($apis[$api_id])) {
            try {
                $client = new SoapClient($apis[$api_id]['url'], ['exceptions' => true]);
                $response = $client->getcredit([
                    'user' => $apis[$api_id]['user'],
                    'pass' => $apis[$api_id]['pass']
                ]);
                echo '<div class="updated"><p>' . __('اتصال برقرار شد.', 'smsadmin') . '</p></div>';
            } catch (Exception $e) {
                smsadmin_log_api_error($e->getMessage());
                echo '<div class="error"><p>' . sprintf(__('اتصال ناموفق بود: %s', 'smsadmin'), $e->getMessage()) . '</p></div>';
            }
        }
    }

    $apis = get_option('smsadmin_api_settings', []);
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('تنظیمات API', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 20px;">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('افزودن API', 'smsadmin'); ?></h3>
            <form method="post">
                <?php wp_nonce_field('smsadmin_api_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('نام API', 'smsadmin'); ?></label></th>
                        <td><input type="text" name="api_name" required style="font-family: Tahoma; width: 100%;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('نام کاربری', 'smsadmin'); ?></label></th>
                        <td><input type="text" name="api_user" required style="font-family: Tahoma; width: 100%;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('رمز عبور', 'smsadmin'); ?></label></th>
                        <td><input type="password" name="api_pass" required style="font-family: Tahoma; width: 100%;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('شماره فرستنده', 'smsadmin'); ?></label></th>
                        <td><input type="text" name="api_from" required style="font-family: Tahoma; width: 100%;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('آدرس API', 'smsadmin'); ?></label></th>
                        <td><input type="url" name="api_url" required style="font-family: Tahoma; width: 100%;"></td>
                    </tr>
                </table>
                <button type="submit" name="save_api" class="button button-primary" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('ذخیره API', 'smsadmin'); ?>
                </button>
            </form>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('مدیریت API‌ها', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('نام API', 'smsadmin'); ?></th>
                        <th><?php _e('نام کاربری', 'smsadmin'); ?></th>
                        <th><?php _e('شماره فرستنده', 'smsadmin'); ?></th>
                        <th><?php _e('آدرس API', 'smsadmin'); ?></th>
                        <th><?php _e('عملیات', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($apis as $id => $api): ?>
                        <tr>
                            <td><?php echo esc_html($api['name']); ?></td>
                            <td><?php echo esc_html($api['user']); ?></td>
                            <td><?php echo esc_html($api['from']); ?></td>
                            <td><?php echo esc_html($api['url']); ?></td>
                            <td>
                                <form method="post" style="display: inline;">
                                    <?php wp_nonce_field('smsadmin_api_nonce'); ?>
                                    <input type="hidden" name="test_api" value="<?php echo esc_attr($id); ?>">
                                    <button type="submit" class="button" 
                                        style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                        <?php _e('تست اتصال', 'smsadmin'); ?>
                                    </button>
                                </form>
                                <form method="post" style="display: inline;">
                                    <?php wp_nonce_field('smsadmin_api_nonce'); ?>
                                    <input type="hidden" name="delete_api" value="<?php echo esc_attr($id); ?>">
                                    <button type="submit" class="button" 
                                        style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                        <?php _e('حذف', 'smsadmin'); ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}