<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_send_page() {
    global $wpdb;
    if (isset($_POST['send_sms'])) {
        check_admin_referer('smsadmin_send_nonce');
        $group_id = absint($_POST['group_id']);
        $template_id = absint($_POST['template_id']);
        $message = wp_kses_post($_POST['message']);
        $schedule = sanitize_text_field($_POST['schedule']);
        $api_id = absint($_POST['api_id']);
        $numbers = [];

        if ($group_id) {
            $numbers = $wpdb->get_results($wpdb->prepare(
                "SELECT phone FROM {$wpdb->prefix}sms_group_numbers WHERE group_id = %d",
                $group_id
            ));
            $numbers = array_column($numbers, 'phone');
        } elseif (!empty($_POST['numbers'])) {
            $numbers = array_map('sanitize_text_field', explode(',', $_POST['numbers']));
            $numbers = array_filter($numbers, function($number) {
                return preg_match('/^\+?\d{10,15}$/', trim($number));
            });
        }

        if (empty($numbers)) {
            echo '<div class="error"><p>' . __('هیچ شماره‌ای انتخاب نشده است.', 'smsadmin') . '</p></div>';
        } else {
            $apis = get_option('smsadmin_api_settings', []);
            if (!isset($apis[$api_id])) {
                echo '<div class="error"><p>' . __('API معتبر نیست.', 'smsadmin') . '</p></div>';
                return;
            }

            $api = $apis[$api_id];
            try {
                $client = new SoapClient($api['url'], ['exceptions' => true]);
                $response = $client->sendmultiple([
                    'user' => $api['user'],
                    'pass' => $api['pass'],
                    'to' => $numbers,
                    'from' => [$api['from']],
                    'text' => [$message]
                ]);
                $status = $response->id ? 'ارسال‌شده' : 'ناموفق';
                foreach ($numbers as $number) {
                    $wpdb->insert($wpdb->prefix . 'sms_logs', [
                        'date' => current_time('mysql'),
                        'type' => $group_id ? 'گروهی' : 'تکی',
                        'phone' => $number,
                        'message' => $message,
                        'status' => $status
                    ]);
                }
                if ($schedule) {
                    wp_schedule_single_event(strtotime($schedule), 'smsadmin_scheduled_send', [
                        'numbers' => $numbers,
                        'message' => $message,
                        'type' => $group_id ? 'گروهی' : 'تکی',
                        'api_id' => $api_id
                    ]);
                    echo '<div class="updated"><p>' . __('ارسال زمان‌بندی شد.', 'smsadmin') . '</p></div>';
                } else {
                    echo '<div class="updated"><p>' . __('پیامک‌ها ارسال شدند.', 'smsadmin') . '</p></div>';
                }
            } catch (Exception $e) {
                smsadmin_log_api_error($e->getMessage());
                echo '<div class="error"><p>' . __('خطا در ارسال: ', 'smsadmin') . $e->getMessage() . '</p></div>';
            }
        }
    }

    if (isset($_POST['upload_numbers']) && !empty($_FILES['numbers_file']['name'])) {
        check_admin_referer('smsadmin_send_nonce');
        $file = $_FILES['numbers_file'];
        if (in_array($file['type'], ['text/csv', 'text/plain', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])) {
            $content = file_get_contents($file['tmp_name']);
            $numbers = array_map('trim', explode("\n", $content));
            $numbers = array_filter($numbers, function($number) {
                return preg_match('/^\+?\d{10,15}$/', $number);
            });
            if (!empty($numbers)) {
                $message = wp_kses_post($_POST['message']);
                $api_id = absint($_POST['api_id']);
                $apis = get_option('smsadmin_api_settings', []);
                if (!isset($apis[$api_id])) {
                    echo '<div class="error"><p>' . __('API معتبر نیست.', 'smsadmin') . '</p></div>';
                    return;
                }
                $api = $apis[$api_id];
                try {
                    $client = new SoapClient($api['url'], ['exceptions' => true]);
                    $response = $client->sendmultiple([
                        'user' => $api['user'],
                        'pass' => $api['pass'],
                        'to' => $numbers,
                        'from' => [$api['from']],
                        'text' => [$message]
                    ]);
                    $status = $response->id ? 'ارسال‌شده' : 'ناموفق';
                    foreach ($numbers as $number) {
                        $wpdb->insert($wpdb->prefix . 'sms_logs', [
                            'date' => current_time('mysql'),
                            'type' => 'گروهی',
                            'phone' => $number,
                            'message' => $message,
                            'status' => $status
                        ]);
                    }
                    echo '<div class="updated"><p>' . __('پیامک‌ها ارسال شدند.', 'smsadmin') . '</p></div>';
                } catch (Exception $e) {
                    smsadmin_log_api_error($e->getMessage());
                    echo '<div class="error"><p>' . __('خطا در ارسال: ', 'smsadmin') . $e->getMessage() . '</p></div>';
                }
            }
        } else {
            echo '<div class="error"><p>' . __('فرمت فایل نامعتبر است.', 'smsadmin') . '</p></div>';
        }
    }

    $groups = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_groups ORDER BY name");
    $templates = get_option('smsadmin_templates', []);
    $apis = get_option('smsadmin_api_settings', []);
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('ارسال پیامک', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-tabs">
            <ul class="nav-tab-wrapper">
                <li><a href="#tab-send-single" class="nav-tab nav-tab-active"><?php _e('ارسال تکی', 'smsadmin'); ?></a></li>
                <li><a href="#tab-send-group" class="nav-tab"><?php _e('ارسال گروهی', 'smsadmin'); ?></a></li>
                <li><a href="#tab-send-newsletter" class="nav-tab"><?php _e('خبرنامه', 'smsadmin'); ?></a></li>
            </ul>
            <div id="tab-send-single" class="tab-content">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('ارسال پیامک تکی', 'smsadmin'); ?></h3>
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('smsadmin_send_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('شماره‌ها (جدا شده با کاما)', 'smsadmin'); ?></label></th>
                                <td><textarea name="numbers" style="font-family: Tahoma; width: 100%; height: 100px; overflow-y: auto;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب قالب', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="template_id" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون قالب', 'smsadmin'); ?></option>
                                        <?php foreach ($templates as $id => $template): ?>
                                            <option value="<?php echo esc_attr($id); ?>">
                                                <?php echo esc_html($template['title']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('متن پیام', 'smsadmin'); ?></label></th>
                                <td><textarea name="message" required style="font-family: Tahoma; width: 100%; height: 150px;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('زمان‌بندی', 'smsadmin'); ?></label></th>
                                <td><input type="datetime-local" name="schedule" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب API', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="api_id" required style="font-family: Tahoma;">
                                        <option value=""><?php _e('انتخاب کنید', 'smsadmin'); ?></option>
                                        <?php foreach ($apis as $id => $api): ?>
                                            <option value="<?php echo esc_attr($id); ?>">
                                                <?php echo esc_html($api['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        <button type="submit" name="send_sms" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ارسال پیامک', 'smsadmin'); ?>
                        </button>
                        <button type="button" class="button preview-sms" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('پیش‌نمایش', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-send-group" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('ارسال پیامک گروهی', 'smsadmin'); ?></h3>
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('smsadmin_send_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب گروه', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="group_id" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون گروه', 'smsadmin'); ?></option>
                                        <?php foreach ($groups as $group): ?>
                                            <option value="<?php echo esc_attr($group->id); ?>">
                                                <?php echo esc_html($group->name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('آپلود فایل (TXT/CSV/Excel)', 'smsadmin'); ?></label></th>
                                <td><input type="file" name="numbers_file" accept=".txt,.csv,.xls,.xlsx" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب قالب', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="template_id" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون قالب', 'smsadmin'); ?></option>
                                        <?php foreach ($templates as $id => $template): ?>
                                            <option value="<?php echo esc_attr($id); ?>">
                                                <?php echo esc_html($template['title']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('متن پیام', 'smsadmin'); ?></label></th>
                                <td><textarea name="message" required style="font-family: Tahoma; width: 100%; height: 150px;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('زمان‌بندی', 'smsadmin'); ?></label></th>
                                <td><input type="datetime-local" name="schedule" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب API', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="api_id" required style="font-family: Tahoma;">
                                        <option value=""><?php _e('انتخاب کنید', 'smsadmin'); ?></option>
                                        <?php foreach ($apis as $id => $api): ?>
                                            <option value="<?php echo esc_attr($id); ?>">
                                                <?php echo esc_html($api['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        <button type="submit" name="send_sms" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma; margin-left: 10px;">
                            <?php _e('ارسال پیامک', 'smsadmin'); ?>
                        </button>
                        <button type="submit" name="upload_numbers" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ارسال با فایل', 'smsadmin'); ?>
                        </button>
                        <button type="button" class="button preview-sms" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('پیش‌نمایش', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-send-newsletter" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('ارسال خبرنامه', 'smsadmin'); ?></h3>
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('smsadmin_send_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب گروه', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="group_id" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون گروه', 'smsadmin'); ?></option>
                                        <?php foreach ($groups as $group): ?>
                                            <option value="<?php echo esc_attr($group->id); ?>">
                                                <?php echo esc_html($group->name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('آپلود فایل (TXT/CSV/Excel)', 'smsadmin'); ?></label></th>
                                <td><input type="file" name="numbers_file" accept=".txt,.csv,.xls,.xlsx" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب قالب', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="template_id" style="font-family: Tahoma;">
                                        <option value="0"><?php _e('بدون قالب', 'smsadmin'); ?></option>
                                        <?php foreach ($templates as $id => $template): ?>
                                            <option value="<?php echo esc_attr($id); ?>">
                                                <?php echo esc_html($template['title']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('متن پیام', 'smsadmin'); ?></label></th>
                                <td><textarea name="message" required style="font-family: Tahoma; width: 100%; height: 150px;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label Sixty style="font-family: Tahoma;"><?php _e('زمان‌بندی دوره‌ای', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="schedule" style="font-family: Tahoma;">
                                        <option value=""><?php _e('بدون زمان‌بندی', 'smsadmin'); ?></option>
                                        <option value="daily"><?php _e('روزانه', 'smsadmin'); ?></option>
                                        <option value="weekly"><?php _e('هفتگی', 'smsadmin'); ?></option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب API', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="api_id" required style="font-family: Tahoma;">
                                        <option value=""><?php _e('انتخاب کنید', 'smsadmin'); ?></option>
                                        <?php foreach ($apis as $id => $api): ?>
                                            <option value="<?php echo esc_attr($id); ?>">
                                                <?php echo esc_html($api['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                        </table>
                        <button type="submit" name="send_sms" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma; margin-left: 10px;">
                            <?php _e('ارسال خبرنامه', 'smsadmin'); ?>
                        </button>
                        <button type="submit" name="upload_numbers" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ارسال با فایل', 'smsadmin'); ?>
                        </button>
                        <button type="button" class="button preview-sms" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('پیش‌نمایش', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('.nav-tab').on('click', function(e) {
                    e.preventDefault();
                    $('.nav-tab').removeClass('nav-tab-active');
                    $(this).addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $($(this).attr('href')).show();
                });
                $('.preview-sms').on('click', function() {
                    var message = $('textarea[name="message"]').val();
                    alert('<?php _e('پیش‌نمایش پیام:', 'smsadmin'); ?>\n' + message);
                });
            });
        </script>
    </div>
    <?php
}

add_action('smsadmin_scheduled_send', function($args) {
    global $wpdb;
    $numbers = $args['numbers'];
    $message = $args['message'];
    $type = $args['type'];
    $api_id = $args['api_id'];

    $apis = get_option('smsadmin_api_settings', []);
    if (!isset($apis[$api_id])) return;

    $api = $apis[$api_id];
    try {
        $client = new SoapClient($api['url'], ['exceptions' => true]);
        $response = $client->sendmultiple([
            'user' => $api['user'],
            'pass' => $api['pass'],
            'to' => $numbers,
            'from' => [$api['from']],
            'text' => [$message]
        ]);
        $status = $response->id ? 'ارسال‌شده' : 'ناموفق';
        foreach ($numbers as $number) {
            $wpdb->insert($wpdb->prefix . 'sms_logs', [
                'date' => current_time('mysql'),
                'type' => $type,
                'phone' => $number,
                'message' => $message,
                'status' => $status
            ]);
        }
    } catch (Exception $e) {
        smsadmin_log_api_error($e->getMessage());
        foreach ($numbers as $number) {
            $wpdb->insert($wpdb->prefix . 'sms_logs', [
                'date' => current_time('mysql'),
                'type' => $type,
                'phone' => $number,
                'message' => $message,
                'status' => 'ناموفق'
            ]);
        }
    }
}, 10, 1);
?>