<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

add_action('wp_ajax_smsadmin_view_log', function() {
    global $wpdb;
    check_ajax_referer('smsadmin_nonce', 'nonce');
    $log_id = absint($_POST['id']);
    $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}sms_logs WHERE id = %d", $log_id));
    if ($log) {
        wp_send_json_success([
            'message' => sprintf(
                __('نوع: %s\nشماره: %s\nپیام: %s\nوضعیت: %s\nتاریخ: %s', 'smsadmin'),
                $log->type,
                $log->phone,
                $log->message,
                $log->status,
                $log->date
            )
        ]);
    } else {
        wp_send_json_error(__('لاگ یافت نشد.', 'smsadmin'));
    }
});
?>