<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_groups_page() {
    global $wpdb;
    if (isset($_POST['save_group'])) {
        check_admin_referer('smsadmin_group_nonce');
        $group = [
            'name' => sanitize_text_field($_POST['group_name']),
            'description' => wp_kses_post($_POST['group_description']),
            'category' => sanitize_text_field($_POST['group_category']),
            'created_at' => current_time('mysql')
        ];
        $wpdb->insert($wpdb->prefix . 'sms_groups', $group);
        echo '<div class="updated"><p>' . __('گروه ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['add_numbers'])) {
        check_admin_referer('smsadmin_group_nonce');
        $group_id = absint($_POST['group_id']);
        $numbers = array_map('sanitize_text_field', explode(',', $_POST['numbers']));
        foreach ($numbers as $number) {
            if (preg_match('/^\+?\d{10,15}$/', trim($number))) {
                $wpdb->insert(
                    $wpdb->prefix . 'sms_group_numbers',
                    [
                        'group_id' => $group_id,
                        'phone' => trim($number),
                        'name' => '',
                        'added_at' => current_time('mysql')
                    ]
                );
            }
        }
        echo '<div class="updated"><p>' . __('شماره‌ها اضافه شدند.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['upload_numbers']) && !empty($_FILES['numbers_file']['name'])) {
        check_admin_referer('smsadmin_group_nonce');
        $group_id = absint($_POST['group_id']);
        $file = $_FILES['numbers_file'];
        if (in_array($file['type'], ['text/csv', 'text/plain', 'application/vnd.ms-excel'])) {
            $content = file_get_contents($file['tmp_name']);
            $numbers = array_map('trim', explode("\n", $content));
            foreach ($numbers as $number) {
                if (preg_match('/^\+?\d{10,15}$/', $number)) {
                    $wpdb->insert(
                        $wpdb->prefix . 'sms_group_numbers',
                        [
                            'group_id' => $group_id,
                            'phone' => $number,
                            'name' => '',
                            'added_at' => current_time('mysql')
                        ]
                    );
                }
            }
            echo '<div class="updated"><p>' . __('فایل شماره‌ها آپلود شد.', 'smsadmin') . '</p></div>';
        } else {
            echo '<div class="error"><p>' . __('فرمت فایل نامعتبر است.', 'smsadmin') . '</p></div>';
        }
    }

    if (isset($_POST['delete_group'])) {
        check_admin_referer('smsadmin_group_nonce');
        $group_id = absint($_POST['delete_group']);
        $wpdb->delete($wpdb->prefix . 'sms_groups', ['id' => $group_id]);
        $wpdb->delete($wpdb->prefix . 'sms_group_numbers', ['group_id' => $group_id]);
        echo '<div class="updated"><p>' . __('گروه حذف شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['add_blacklist'])) {
        check_admin_referer('smsadmin_group_nonce');
        $number = sanitize_text_field($_POST['blacklist_number']);
        if (preg_match('/^\+?\d{10,15}$/', $number)) {
            $wpdb->insert(
                $wpdb->prefix . 'sms_group_numbers',
                [
                    'group_id' => 0,
                    'phone' => $number,
                    'name' => 'blacklist',
                    'added_at' => current_time('mysql')
                ]
            );
            echo '<div class="updated"><p>' . __('شماره به لیست سیاه اضافه شد.', 'smsadmin') . '</p></div>';
        }
    }

    $groups = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_groups ORDER BY created_at DESC");
    $blacklist = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_group_numbers WHERE name = 'blacklist'");
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Vazir, Tahoma, sans-serif; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('گروه‌بندی', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-tabs">
            <ul class="nav-tab-wrapper">
                <li><a href="#tab-add-group" class="nav-tab nav-tab-active"><?php _e('افزودن گروه', 'smsadmin'); ?></a></li>
                <li><a href="#tab-add-numbers" class="nav-tab"><?php _e('افزودن شماره', 'smsadmin'); ?></a></li>
                <li><a href="#tab-blacklist" class="nav-tab"><?php _e('لیست سیاه', 'smsadmin'); ?></a></li>
                <li><a href="#tab-manage-groups" class="nav-tab"><?php _e('مدیریت گروه‌ها', 'smsadmin'); ?></a></li>
            </ul>
            <div id="tab-add-group" class="tab-content">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('افزودن گروه جدید', 'smsadmin'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_group_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('نام گروه', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="group_name" required style="font-family: Tahoma; width: 100%;" placeholder="مثال: مهندسان عمران کرمانشاه"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('توضیحات', 'smsadmin'); ?></label></th>
                                <td><textarea name="group_description" style="font-family: Tahoma; width: 100%; height: 100px;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('دسته‌بندی', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="group_category" style="font-family: Tahoma; width: 100%;" placeholder="مثال: خبرنامه"></td>
                            </tr>
                        </table>
                        <button type="submit" name="save_group" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('ذخیره گروه', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-add-numbers" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('افزودن شماره به گروه', 'smsadmin'); ?></h3>
                    <form method="post" enctype="multipart/form-data">
                        <?php wp_nonce_field('smsadmin_group_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('انتخاب گروه', 'smsadmin'); ?></label></th>
                                <td>
                                    <select name="group_id" required style="font-family: Tahoma;">
                                        <option value=""><?php _e('انتخاب کنید', 'smsadmin'); ?></option>
                                        <?php foreach ($groups as $group): ?>
                                            <option value="<?php echo esc_attr($group->id); ?>">
                                                <?php echo esc_html($group->name); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('شماره‌ها (جدا شده با کاما)', 'smsadmin'); ?></label></th>
                                <td><textarea name="numbers" style="font-family: Tahoma; width: 100%; height: 100px; overflow-y: auto;"></textarea></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('آپلود فایل (TXT/CSV/Excel)', 'smsadmin'); ?></label></th>
                                <td><input type="file" name="numbers_file" accept=".txt,.csv,.xls,.xlsx" style="font-family: Tahoma;"></td>
                            </tr>
                        </table>
                        <button type="submit" name="add_numbers" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma; margin-left: 10px;">
                            <?php _e('افزودن شماره‌ها', 'smsadmin'); ?>
                        </button>
                        <button type="submit" name="upload_numbers" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('آپلود فایل', 'smsadmin'); ?>
                        </button>
                    </form>
                </div>
            </div>
            <div id="tab-blacklist" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('مدیریت لیست سیاه', 'smsadmin'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('smsadmin_group_nonce'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;"><?php _e('شماره برای لیست سیاه', 'smsadmin'); ?></label></th>
                                <td><input type="text" name="blacklist_number" style="font-family: Tahoma; width: 100%;"></td>
                            </tr>
                        </table>
                        <button type="submit" name="add_blacklist" class="button button-primary" 
                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                            <?php _e('اضافه به لیست سیاه', 'smsadmin'); ?>
                        </button>
                    </form>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('شماره', 'smsadmin'); ?></th>
                                <th><?php _e('تاریخ افزودن', 'smsadmin'); ?></th>
                                <th><?php _e('عملیات', 'smsadmin'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($blacklist as $item): ?>
                                <tr>
                                    <td><?php echo esc_html($item->phone); ?></td>
                                    <td><?php echo esc_html($item->added_at); ?></td>
                                    <td>
                                        <form method="post" style="display: inline;">
                                            <?php wp_nonce_field('smsadmin_group_nonce'); ?>
                                            <input type="hidden" name="delete_blacklist" value="<?php echo esc_attr($item->id); ?>">
                                            <button type="submit" class="button" 
                                                style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                                <?php _e('حذف', 'smsadmin'); ?>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="tab-manage-groups" class="tab-content" style="display: none;">
                <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
                    <h3 style="font-family: Vazir, Tahoma, sans-serif; color: #4A4A4A;"><?php _e('گروه‌های موجود', 'smsadmin'); ?></h3>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('نام گروه', 'smsadmin'); ?></th>
                                <th><?php _e('دسته‌بندی', 'smsadmin'); ?></th>
                                <th><?php _e('تعداد شماره‌ها', 'smsadmin'); ?></th>
                                <th><?php _e('تاریخ ایجاد', 'smsadmin'); ?></th>
                                <th><?php _e('عملیات', 'smsadmin'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($groups as $group): ?>
                                <?php
                                $count = $wpdb->get_var($wpdb->prepare(
                                    "SELECT COUNT(*) FROM {$wpdb->prefix}sms_group_numbers WHERE group_id = %d",
                                    $group->id
                                ));
                                ?>
                                <tr>
                                    <td><?php echo esc_html($group->name); ?></td>
                                    <td><?php echo esc_html($group->category); ?></td>
                                    <td><?php echo esc_html($count); ?></td>
                                    <td><?php echo esc_html($group->created_at); ?></td>
                                    <td>
                                        <form method="post" style="display: inline;">
                                            <?php wp_nonce_field('smsadmin_group_nonce'); ?>
                                            <input type="hidden" name="delete_group" value="<?php echo esc_attr($group->id); ?>">
                                            <button type="submit" class="button" 
                                                style="background: #E74C3C; border: none; color: #4A4A4A; font-family: Tahoma;">
                                                <?php _e('حذف', 'smsadmin'); ?>
                                            </button>
                                        </form>
                                        <button class="button edit-group" 
                                            data-id="<?php echo esc_attr($group->id); ?>" 
                                            data-name="<?php echo esc_attr($group->name); ?>" 
                                            data-description="<?php echo esc_attr($group->description); ?>" 
                                            data-category="<?php echo esc_attr($group->category); ?>" 
                                            style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                                            <?php _e('ویرایش', 'smsadmin'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <script>
            jQuery(document).ready(function($) {
                $('.nav-tab').on('click', function(e) {
                    e.preventDefault();
                    $('.nav-tab').removeClass('nav-tab-active');
                    $(this).addClass('nav-tab-active');
                    $('.tab-content').hide();
                    $($(this).attr('href')).show();
                });
                $('.edit-group').on('click', function() {
                    var id = $(this).data('id');
                    $('input[name="group_name"]').val($(this).data('name'));
                    $('textarea[name="group_description"]').val($(this).data('description'));
                    $('input[name="group_category"]').val($(this).data('category'));
                    $('.nav-tab[href="#tab-add-group"]').click();
                });
            });
        </script>
    </div>
    <?php
}
?>