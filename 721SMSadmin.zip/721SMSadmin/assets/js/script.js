jQuery(document).ready(function($) {
    $('.smsadmin-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        $('.tab-content').hide();
        $($(this).attr('href')).show();
    });

    $('.wp-list-table').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/fa.json'
        },
        pageLength: 5,
        ordering: true,
        searching: true,
        paging: true
    });

    $('.preview-sms').on('click', function() {
        var message = $('textarea[name="message"]').val();
        alert('پیش‌نمایش پیام:\n' + message);
    });

    $('.view-error, .view-api-error, .view-log').on('click', function() {
        var data = $(this).data();
        $.post(smsAdminAjax.ajaxurl, {
            action: $(this).hasClass('view-error') ? 'smsadmin_view_error' : 
                    $(this).hasClass('view-api-error') ? 'smsadmin_view_api_error' : 'smsadmin_view_log',
            nonce: smsAdminAjax.nonce,
            id: data.id || data.file
        }, function(response) {
            alert(response.data);
        });
    });
});