<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_reports_page() {
    global $wpdb;
    $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_logs ORDER BY date DESC LIMIT 50");
    $errors = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_errors ORDER BY date DESC LIMIT 50");
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('گزارش‌ها', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('لاگ‌های پیامک', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('تاریخ', 'smsadmin'); ?></th>
                        <th><?php _e('نوع', 'smsadmin'); ?></th>
                        <th><?php _e('شماره', 'smsadmin'); ?></th>
                        <th><?php _e('پیام', 'smsadmin'); ?></th>
                        <th><?php _e('وضعیت', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log) : ?>
                        <tr>
                            <td><?php echo date_i18n('Y-m-d H:i:s', strtotime($log->date)); ?></td>
                            <td><?php echo esc_html($log->type); ?></td>
                            <td><?php echo esc_html($log->phone); ?></td>
                            <td><?php echo esc_html($log->message); ?></td>
                            <td><?php echo esc_html($log->status); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('لاگ‌های خطا', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('تاریخ', 'smsadmin'); ?></th>
                        <th><?php _e('بخش', 'smsadmin'); ?></th>
                        <th><?php _e('توضیحات', 'smsadmin'); ?></th>
                        <th><?php _e('وضعیت', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($errors as $error) : ?>
                        <tr>
                            <td><?php echo date_i18n('Y-m-d H:i:s', strtotime($error->date)); ?></td>
                            <td><?php echo esc_html($error->section); ?></td>
                            <td><?php echo esc_html($error->description); ?></td>
                            <td><?php echo esc_html($error->status); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}