<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_settings_page() {
    $settings = get_option('smsadmin_settings', [
        'send_login' => '0',
        'send_password' => '0',
        'send_order' => '0',
        'send_newsletter' => '0',
        'send_register' => '0',
        'send_order_status' => '0',
        'daily_limit' => '1000',
        'default_template' => '0',
        'api_priority' => 'normal',
        'schedule_type' => '',
        'custom_events' => []
    ]);

    $message = '';
    if (isset($_POST['save_settings'])) {
        check_admin_referer('smsadmin_settings_nonce');
        $settings = [
            'send_login' => isset($_POST['send_login']) ? '1' : '0',
            'send_password' => isset($_POST['send_password']) ? '1' : '0',
            'send_order' => isset($_POST['send_order']) ? '1' : '0',
            'send_newsletter' => isset($_POST['send_newsletter']) ? '1' : '0',
            'send_register' => isset($_POST['send_register']) ? '1' : '0',
            'send_order_status' => isset($_POST['send_order_status']) ? '1' : '0',
            'daily_limit' => absint($_POST['daily_limit'] ?? '1000'),
            'default_template' => sanitize_text_field($_POST['default_template'] ?? '0'),
            'api_priority' => sanitize_text_field($_POST['api_priority'] ?? 'normal'),
            'schedule_type' => sanitize_text_field($_POST['schedule_type'] ?? ''),
            'custom_events' => array_map(function($event) {
                return [
                    'hook' => sanitize_text_field($event['hook'] ?? ''),
                    'template_id' => sanitize_text_field($event['template_id'] ?? ''),
                    'phone_field' => sanitize_text_field($event['phone_field'] ?? '')
                ];
            }, $_POST['custom_events'] ?? [])
        ];
        update_option('smsadmin_settings', $settings);
        $message = '<div class="updated"><p>' . __('تنظیمات ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    $templates = get_option('smsadmin_templates', []);
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('تنظیمات پیشرفته', 'smsadmin'); ?>
        </h1>
        <?php echo $message; ?>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('تنظیمات عمومی', 'smsadmin'); ?></h3>
            <form method="post">
                <?php wp_nonce_field('smsadmin_settings_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('ارسال هنگام ورود', 'smsadmin'); ?></label></th>
                        <td><input type="checkbox" name="send_login" value="1" <?php checked($settings['send_login'], '1'); ?>></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('ارسال هنگام بازیابی رمز', 'smsadmin'); ?></label></th>
                        <td><input type="checkbox" name="send_password" value="1" <?php checked($settings['send_password'], '1'); ?>></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('ارسال هنگام سفارش', 'smsadmin'); ?></label></th>
                        <td><input type="checkbox" name="send_order" value="1" <?php checked($settings['send_order'], '1'); ?>></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('ارسال خبرنامه', 'smsadmin'); ?></label></th>
                        <td><input type="checkbox" name="send_newsletter" value="1" <?php checked($settings['send_newsletter'], '1'); ?>></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('ارسال هنگام ثبت‌نام', 'smsadmin'); ?></label></th>
                        <td><input type="checkbox" name="send_register" value="1" <?php checked($settings['send_register'], '1'); ?>></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('ارسال تغییر وضعیت سفارش', 'smsadmin'); ?></label></th>
                        <td><input type="checkbox" name="send_order_status" value="1" <?php checked($settings['send_order_status'], '1'); ?>></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('حد روزانه ارسال', 'smsadmin'); ?></label></th>
                        <td><input type="number" name="daily_limit" value="<?php echo esc_attr($settings['daily_limit']); ?>" style="font-family: Tahoma;"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('قالب پیش‌فرض', 'smsadmin'); ?></label></th>
                        <td>
                            <select name="default_template" style="font-family: Tahoma;">
                                <option value="0"><?php _e('هیچکدام', 'smsadmin'); ?></option>
                                <?php foreach ($templates as $key => $template) : ?>
                                    <option value="<?php echo esc_attr($key); ?>" <?php selected($settings['default_template'], $key); ?>>
                                        <?php echo esc_html($template['title']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
                <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('رویدادهای سفارشی', 'smsadmin'); ?></h3>
                <div id="custom-events">
                    <?php foreach ($settings['custom_events'] as $index => $event) : ?>
                        <div class="custom-event">
                            <table class="form-table">
                                <tr>
                                    <th><label style="font-family: Tahoma;"><?php _e('هوک', 'smsadmin'); ?></label></th>
                                    <td><input type="text" name="custom_events[<?php echo $index; ?>][hook]" value="<?php echo esc_attr($event['hook']); ?>" style="font-family: Tahoma;"></td>
                                </tr>
                                <tr>
                                    <th><label style="font-family: Tahoma;"><?php _e('قالب', 'smsadmin'); ?></label></th>
                                    <td>
                                        <select name="custom_events[<?php echo $index; ?>][template_id]" style="font-family: Tahoma;">
                                            <option value=""><?php _e('انتخاب کنید', 'smsadmin'); ?></option>
                                            <?php foreach ($templates as $key => $template) : ?>
                                                <option value="<?php echo esc_attr($key); ?>" <?php selected($event['template_id'], $key); ?>>
                                                    <?php echo esc_html($template['title']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th><label style="font-family: Tahoma;"><?php _e('فیلد شماره', 'smsadmin'); ?></label></th>
                                    <td><input type="text" name="custom_events[<?php echo $index; ?>][phone_field]" value="<?php echo esc_attr($event['phone_field']); ?>" style="font-family: Tahoma;"></td>
                                </tr>
                            </table>
                        </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" id="add-custom-event" class="button" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('اضافه کردن رویداد', 'smsadmin'); ?>
                </button>
                <button type="submit" name="save_settings" class="button button-primary" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('ذخیره تنظیمات', 'smsadmin'); ?>
                </button>
            </form>
        </div>
    </div>
    <script>
        jQuery(document).ready(function($) {
            $('#add-custom-event').click(function() {
                var index = $('.custom-event').length;
                var html = `
                    <div class="custom-event">
                        <table class="form-table">
                            <tr>
                                <th><label style="font-family: Tahoma;">هوک</label></th>
                                <td><input type="text" name="custom_events[${index}][hook]" style="font-family: Tahoma;"></td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;">قالب</label></th>
                                <td>
                                    <select name="custom_events[${index}][template_id]" style="font-family: Tahoma;">
                                        <option value=""><?php _e('انتخاب کنید', 'smsadmin'); ?></option>
                                        <?php foreach ($templates as $key => $template) : ?>
                                            <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($template['title']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label style="font-family: Tahoma;">فیلد شماره</label></th>
                                <td><input type="text" name="custom_events[${index}][phone_field]" style="font-family: Tahoma;"></td>
                            </tr>
                        </table>
                    </div>`;
                $('#custom-events').append(html);
            });
        });
    </script>
    <?php
}