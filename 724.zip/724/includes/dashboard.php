<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_dashboard_page() {
    global $wpdb;
    $config = get_option('smsadmin_config', []);
    require_once SMSADMIN_DIR . 'api/balance.php';
    $balance = smsadmin_api_balance($config);
    $sent_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'sent'");
    $failed_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_logs WHERE status = 'failed'");
    $error_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_errors WHERE status = 'open'");
    $groups_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}sms_groups");
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('داشبورد SMSadmin 724', 'smsadmin'); ?>
        </h1>
        <div class="smsadmin-boxes" style="display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 20px;">
            <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 200px;">
                <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('اعتبار پنل', 'smsadmin'); ?></h3>
                <p style="font-family: Tahoma; font-size: 18px; color: #4A90E2;">
                    <?php echo $balance['status'] === 'success' ? esc_html($balance['balance']) . ' ' . __('ریال', 'smsadmin') : esc_html($balance['message']); ?>
                </p>
            </div>
            <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 200px;">
                <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('پیامک‌های ارسالی', 'smsadmin'); ?></h3>
                <p style="font-family: Tahoma; font-size: 18px; color: #4A90E2;"><?php echo esc_html($sent_count); ?></p>
            </div>
            <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 200px;">
                <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('پیامک‌های ناموفق', 'smsadmin'); ?></h3>
                <p style="font-family: Tahoma; font-size: 18px; color: #FF6B6B;"><?php echo esc_html($failed_count); ?></p>
            </div>
            <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 200px;">
                <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('خطاهای باز', 'smsadmin'); ?></h3>
                <p style="font-family: Tahoma; font-size: 18px; color: #FF6B6B;"><?php echo esc_html($error_count); ?></p>
            </div>
            <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; min-width: 200px;">
                <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('گروه‌های فعال', 'smsadmin'); ?></h3>
                <p style="font-family: Tahoma; font-size: 18px; color: #4A90E2;"><?php echo esc_html($groups_count); ?></p>
            </div>
        </div>
    </div>
    <?php
}