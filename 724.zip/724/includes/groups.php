<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_groups_page() {
    global $wpdb;
    $message = '';

    if (isset($_POST['add_group'])) {
        check_admin_referer('smsadmin_group_nonce');
        $name = sanitize_text_field($_POST['group_name']);
        $description = sanitize_textarea_field($_POST['group_description']);
        if (!empty($name)) {
            $wpdb->insert(
                "{$wpdb->prefix}sms_groups",
                [
                    'name' => $name,
                    'description' => $description,
                    'created_at' => current_time('mysql')
                ],
                ['%s', '%s', '%s']
            );
            $message = '<div class="updated"><p>' . __('گروه با موفقیت اضافه شد.', 'smsadmin') . '</p></div>';
        } else {
            $message = '<div class="error"><p>' . __('نام گروه الزامی است.', 'smsadmin') . '</p></div>';
        }
    }

    $groups = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_groups ORDER BY created_at DESC");
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('مدیریت گروه‌ها', 'smsadmin'); ?>
        </h1>
        <?php echo $message; ?>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('ایجاد گروه جدید', 'smsadmin'); ?></h3>
            <form method="post">
                <?php wp_nonce_field('smsadmin_group_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('نام گروه', 'smsadmin'); ?></label></th>
                        <td><input type="text" name="group_name" style="font-family: Tahoma;" required></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('توضیحات', 'smsadmin'); ?></label></th>
                        <td><textarea name="group_description" style="font-family: Tahoma;"></textarea></td>
                    </tr>
                </table>
                <button type="submit" name="add_group" class="button button-primary" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('اضافه کردن گروه', 'smsadmin'); ?>
                </button>
            </form>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('لیست گروه‌ها', 'smsadmin'); ?></h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('نام گروه', 'smsadmin'); ?></th>
                        <th><?php _e('توضیحات', 'smsadmin'); ?></th>
                        <th><?php _e('تاریخ ایجاد', 'smsadmin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($groups as $group) : ?>
                        <tr>
                            <td><?php echo esc_html($group->name); ?></td>
                            <td><?php echo esc_html($group->description); ?></td>
                            <td><?php echo date_i18n('Y-m-d H:i:s', strtotime($group->created_at)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}