<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_log_error($section, $description) {
    global $wpdb;
    $wpdb->insert(
        "{$wpdb->prefix}sms_errors",
        [
            'date' => current_time('mysql'),
            'section' => sanitize_text_field($section),
            'description' => sanitize_text_field($description),
            'status' => 'open'
        ],
        ['%s', '%s', '%s', '%s']
    );
}

function smsadmin_handle_custom_events() {
    $settings = get_option('smsadmin_settings', ['custom_events' => []]);
    $config = get_option('smsadmin_config', []);
    $templates = get_option('smsadmin_templates', []);

    if (empty($settings['custom_events']) || empty($config['api_user']) || empty($config['api_pass'])) {
        return;
    }

    foreach ($settings['custom_events'] as $event) {
        if (empty($event['hook']) || empty($event['template_id']) || empty($event['phone_field'])) {
            continue;
        }

        add_action($event['hook'], function($user_id) use ($event, $config, $templates) {
            $user = get_userdata($user_id);
            $phone = get_user_meta($user_id, $event['phone_field'], true);

            if (empty($phone) || !preg_match('/^\+?\d{10,15}$/', $phone)) {
                smsadmin_log_error('رویداد سفارشی', 'شماره تلفن نامعتبر: ' . $event['hook']);
                return;
            }

            $template = $templates[$event['template_id']] ?? null;
            if (!$template) {
                smsadmin_log_error('رویداد سفارشی', 'قالب نامعتبر: ' . $event['template_id']);
                return;
            }

            $message = $template['content'];
            $vars = explode(',', $template['vars']);
            $replacements = [];
            foreach ($vars as $var) {
                $var = trim($var, '{}');
                switch ($var) {
                    case 'نام':
                        $replacements['{' . $var . '}'] = $user->display_name;
                        break;
                    case 'تاریخ':
                        $replacements['{' . $var . '}'] = date_i18n('Y-m-d H:i:s');
                        break;
                    default:
                        $replacements['{' . $var . '}'] = get_user_meta($user_id, $var, true) ?: '';
                }
            }
            $message = strtr($message, $replacements);

            require_once SMSADMIN_DIR . 'api/sendsms.php';
            smsadmin_api_sendsms([$phone], $message, $config);
        });
    }
}
add_action('init', 'smsadmin_handle_custom_events');