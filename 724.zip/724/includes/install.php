<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_install() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $tables = [
        "CREATE TABLE {$wpdb->prefix}sms_groups (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",

        "CREATE TABLE {$wpdb->prefix}sms_group_numbers (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            group_id BIGINT(20) UNSIGNED NOT NULL,
            phone VARCHAR(20) NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY group_id (group_id)
        ) $charset_collate;",

        "CREATE TABLE {$wpdb->prefix}sms_logs (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            date DATETIME NOT NULL,
            type VARCHAR(50) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            message TEXT NOT NULL,
            status VARCHAR(50) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",

        "CREATE TABLE {$wpdb->prefix}sms_errors (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            date DATETIME NOT NULL,
            section VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            status VARCHAR(50) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",

        "CREATE TABLE {$wpdb->prefix}sms_users (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL,
            access TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;"
    ];

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    foreach ($tables as $table) {
        dbDelta($table);
    }

    $templates = [
        'welcome' => [
            'title' => 'خوش‌آمدگویی',
            'content' => 'خوش آمدید، {نام}! ثبت‌نام شما در تاریخ {تاریخ} انجام شد.',
            'vars' => '{نام},{تاریخ}'
        ],
        'order' => [
            'title' => 'تکمیل سفارش',
            'content' => 'سفارش #{سفارش} تکمیل شد. محصول: {محصول}',
            'vars' => '{سفارش},{محصول}'
        ]
    ];
    update_option('smsadmin_templates', $templates);

    $settings = [
        'send_login' => '0',
        'send_password' => '0',
        'send_order' => '0',
        'send_newsletter' => '0',
        'send_register' => '0',
        'send_order_status' => '0',
        'daily_limit' => '1000',
        'default_template' => '0',
        'api_priority' => 'normal',
        'schedule_type' => '',
        'custom_events' => []
    ];
    update_option('smsadmin_settings', $settings);

    $config = [
        'api_user' => '',
        'api_pass' => '',
        'api_from' => '50002010096323',
        'api_url' => 'https://smsadmin.ir/webservice/index.php?wsdl',
        'admin_email' => get_option('admin_email', ''),
        'admin_phone' => ''
    ];
    update_option('smsadmin_config', $config);

    update_option('smsadmin_version', SMSADMIN_VERSION);
}