<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_config_page() {
    $config = get_option('smsadmin_config', [
        'api_user' => '',
        'api_pass' => '',
        'api_from' => '50002010096323',
        'api_url' => 'https://smsadmin.ir/webservice/index.php?wsdl',
        'admin_email' => get_option('admin_email', ''),
        'admin_phone' => ''
    ]);

    $message = '';
    $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'credentials';

    if (isset($_POST['save_config'])) {
        check_admin_referer('smsadmin_config_nonce');
        $config = [
            'api_user' => sanitize_text_field($_POST['api_user'] ?? ''),
            'api_pass' => sanitize_text_field($_POST['api_pass'] ?? ''),
            'api_from' => sanitize_text_field($_POST['api_from'] ?? '50002010096323'),
            'api_url' => esc_url_raw($_POST['api_url'] ?? 'https://smsadmin.ir/webservice/index.php?wsdl'),
            'admin_email' => sanitize_email($_POST['admin_email'] ?? ''),
            'admin_phone' => sanitize_text_field($_POST['admin_phone'] ?? '')
        ];
        update_option('smsadmin_config', $config);
        $message = '<div class="updated"><p>' . __('تنظیمات ذخیره شد.', 'smsadmin') . '</p></div>';
    }

    if (isset($_POST['test_api'])) {
        check_admin_referer('smsadmin_test_nonce');
        require_once SMSADMIN_DIR . 'api/balance.php';
        $result = smsadmin_api_balance($config);
        $message = $result['status'] === 'success' ?
            '<div class="updated"><p style="color: green;">' . __('اتصال به API برقرار شد.', 'smsadmin') . '</p></div>' :
            '<div class="error"><p style="color: red;">' . sprintf(__('خطا در اتصال: %s', 'smsadmin'), esc_html($result['message'])) . '</p></div>';
    }
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('پیکربندی API', 'smsadmin'); ?>
        </h1>
        <?php echo $message; ?>
        <h2 class="nav-tab-wrapper">
            <a href="?page=smsadmin-config&tab=credentials" class="nav-tab <?php echo $active_tab === 'credentials' ? 'nav-tab-active' : ''; ?>" style="font-family: Tahoma;">
                <?php _e('اطلاعات ورود', 'smsadmin'); ?>
            </a>
            <a href="?page=smsadmin-config&tab=test" class="nav-tab <?php echo $active_tab === 'test' ? 'nav-tab-active' : ''; ?>" style="font-family: Tahoma;">
                <?php _e('تست اتصال', 'smsadmin'); ?>
            </a>
            <a href="?page=smsadmin-config&tab=advanced" class="nav-tab <?php echo $active_tab === 'advanced' ? 'nav-tab-active' : ''; ?>" style="font-family: Tahoma;">
                <?php _e('تنظیمات پیشرفته', 'smsadmin'); ?>
            </a>
        </h2>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <?php if ($active_tab === 'credentials') { ?>
                <form method="post">
                    <?php wp_nonce_field('smsadmin_config_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('نام کاربری API', 'smsadmin'); ?></label></th>
                            <td><input type="text" name="api_user" value="<?php echo esc_attr($config['api_user']); ?>" style="font-family: Tahoma;" required></td>
                        </tr>
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('رمز عبور API', 'smsadmin'); ?></label></th>
                            <td><input type="text" name="api_pass" value="<?php echo esc_attr($config['api_pass']); ?>" style="font-family: Tahoma;" required></td>
                        </tr>
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('شماره فرستنده', 'smsadmin'); ?></label></th>
                            <td><input type="text" name="api_from" value="<?php echo esc_attr($config['api_from']); ?>" style="font-family: Tahoma;" required></td>
                        </tr>
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('آدرس API', 'smsadmin'); ?></label></th>
                            <td><input type="url" name="api_url" value="<?php echo esc_attr($config['api_url']); ?>" style="font-family: Tahoma;" readonly></td>
                        </tr>
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('ایمیل مدیر', 'smsadmin'); ?></label></th>
                            <td><input type="email" name="admin_email" value="<?php echo esc_attr($config['admin_email']); ?>" style="font-family: Tahoma;"></td>
                        </tr>
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('شماره مدیر', 'smsadmin'); ?></label></th>
                            <td><input type="text" name="admin_phone" value="<?php echo esc_attr($config['admin_phone']); ?>" style="font-family: Tahoma;" placeholder="+989123456789"></td>
                        </tr>
                    </table>
                    <button type="submit" name="save_config" class="button button-primary" 
                        style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                        <?php _e('ذخیره تنظیمات', 'smsadmin'); ?>
                    </button>
                </form>
            <?php } elseif ($active_tab === 'test') { ?>
                <form method="post">
                    <?php wp_nonce_field('smsadmin_test_nonce'); ?>
                    <p style="font-family: Tahoma;"><?php _e('برای بررسی اتصال به API، روی دکمه زیر کلیک کنید.', 'smsadmin'); ?></p>
                    <button type="submit" name="test_api" class="button button-primary" 
                        style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                        <?php _e('تست اتصال', 'smsadmin'); ?>
                    </button>
                </form>
            <?php } elseif ($active_tab === 'advanced') { ?>
                <form method="post">
                    <?php wp_nonce_field('smsadmin_config_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('اولویت ارسال', 'smsadmin'); ?></label></th>
                            <td>
                                <select name="api_priority" style="font-family: Tahoma;">
                                    <option value="high"><?php _e('بالا', 'smsadmin'); ?></option>
                                    <option value="normal"><?php _e('عادی', 'smsadmin'); ?></option>
                                    <option value="low"><?php _e('پایین', 'smsadmin'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label style="font-family: Tahoma;"><?php _e('زمان‌بندی ارسال', 'smsadmin'); ?></label></th>
                            <td><input type="text" name="schedule_type" style="font-family: Tahoma;" placeholder="مثال: روزانه"></td>
                        </tr>
                    </table>
                    <button type="submit" name="save_config" class="button button-primary" 
                        style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                        <?php _e('ذخیره تنظیمات', 'smsadmin'); ?>
                    </button>
                </form>
            <?php } ?>
        </div>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
                <?php _e('پشتیبانی', 'smsadmin'); ?>
            </h3>
            <p style="font-family: Tahoma;">
                <?php _e('برای فعال‌سازی اکانت یا دریافت اطلاعات API، با پشتیبانی (واتساپ: <strong>09128855816</strong>) تماس بگیرید.', 'smsadmin'); ?>
            </p>
            <a href="https://wa.me/09128855816" target="_blank" class="button" 
                style="background: #25D366; border: none; color: #4A4A4A; font-family: Tahoma;">
                <?php _e('تماس با پشتیبانی', 'smsadmin'); ?>
            </a>
        </div>
    </div>
    <?php
}