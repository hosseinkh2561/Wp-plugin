<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_send_page() {
    global $wpdb;
    $config = get_option('smsadmin_config', []);
    $message = '';

    if (isset($_POST['send_sms'])) {
        check_admin_referer('smsadmin_send_nonce');
        $numbers = array_map('sanitize_text_field', explode(',', $_POST['numbers']));
        $text = sanitize_textarea_field($_POST['message']);
        $group_id = !empty($_POST['group_id']) ? absint($_POST['group_id']) : 0;

        if ($group_id) {
            $numbers = $wpdb->get_col($wpdb->prepare(
                "SELECT phone FROM {$wpdb->prefix}sms_group_numbers WHERE group_id = %d",
                $group_id
            ));
        }

        if (empty($numbers) || empty($text)) {
            $message = '<div class="error"><p>' . __('شماره یا پیام الزامی است.', 'smsadmin') . '</p></div>';
        } else {
            require_once SMSADMIN_DIR . 'api/sendsms.php';
            $result = smsadmin_api_sendsms($numbers, $text, $config);
            $message = $result['status'] === 'success' ?
                '<div class="updated"><p>' . __('پیامک ارسال شد.', 'smsadmin') . '</p></div>' :
                '<div class="error"><p>' . sprintf(__('خطا: %s', 'smsadmin'), esc_html($result['message'])) . '</p></div>';

            foreach ($numbers as $number) {
                $wpdb->insert(
                    "{$wpdb->prefix}sms_logs",
                    [
                        'date' => current_time('mysql'),
                        'type' => $group_id ? 'group' : 'single',
                        'phone' => $number,
                        'message' => $text,
                        'status' => $result['status'] === 'success' ? 'sent' : 'failed'
                    ],
                    ['%s', '%s', '%s', '%s', '%s']
                );
            }
        }
    }

    $groups = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}sms_groups");
    ?>
    <div class="wrap smsadmin-wrap">
        <h1 style="font-family: Tahoma; text-shadow: 1px 1px 2px rgba(0,0,0,0.1); color: #4A4A4A;">
            <?php _e('ارسال پیامک', 'smsadmin'); ?>
        </h1>
        <?php echo $message; ?>
        <div class="smsadmin-box" style="background: #F5F5F5; padding: 20px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
            <h3 style="font-family: Tahoma; color: #4A4A4A;"><?php _e('ارسال پیامک جدید', 'smsadmin'); ?></h3>
            <form method="post">
                <?php wp_nonce_field('smsadmin_send_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('شماره‌ها (با کاما جدا کنید)', 'smsadmin'); ?></label></th>
                        <td><input type="text" name="numbers" style="font-family: Tahoma;" placeholder="+989123456789,+989987654321"></td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('انتخاب گروه', 'smsadmin'); ?></label></th>
                        <td>
                            <select name="group_id" style="font-family: Tahoma;">
                                <option value="0"><?php _e('بدون گروه', 'smsadmin'); ?></option>
                                <?php foreach ($groups as $group) : ?>
                                    <option value="<?php echo esc_attr($group->id); ?>"><?php echo esc_html($group->name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label style="font-family: Tahoma;"><?php _e('متن پیامک', 'smsadmin'); ?></label></th>
                        <td><textarea name="message" style="font-family: Tahoma;" required></textarea></td>
                    </tr>
                </table>
                <button type="submit" name="send_sms" class="button button-primary" 
                    style="background: #4A90E2; border: none; color: #4A4A4A; font-family: Tahoma;">
                    <?php _e('ارسال پیامک', 'smsadmin'); ?>
                </button>
            </form>
        </div>
    </div>
    <?php
}