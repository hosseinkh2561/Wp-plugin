<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_api_receive($config) {
    if (empty($config['api_user']) || empty($config['api_pass']) || empty($config['api_from'])) {
        smsadmin_log_error('دریافت پیامک', 'اطلاعات API ناقص است.');
        return ['status' => 'error', 'message' => __('اطلاعات API ناقص است.', 'smsadmin')];
    }

    try {
        $client = new SoapClient($config['api_url'], [
            'encoding' => 'UTF-8',
            'exceptions' => true,
            'trace' => true,
            'cache_wsdl' => WSDL_CACHE_NONE
        ]);
        $response = $client->receive([
            'user' => (int)$config['api_user'],
            'pass' => (string)$config['api_pass'],
            'from' => (string)$config['api_from']
        ]);

        error_log('smsadmin_api_receive response: ' . print_r($response, true));

        if (is_array($response) && !empty($response)) {
            return ['status' => 'success', 'messages' => $response];
        } elseif (is_object($response) && !empty($response->id)) {
            return ['status' => 'success', 'messages' => (array)$response];
        } else {
            return ['status' => 'error', 'message' => __('پاسخ نامعتبر یا خالی از API', 'smsadmin')];
        }
    } catch (Exception $e) {
        smsadmin_log_error('دریافت پیامک', $e->getMessage());
        error_log('smsadmin_api_receive error: ' . $e->getMessage());
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}