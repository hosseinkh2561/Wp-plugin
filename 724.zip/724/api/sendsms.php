<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_api_sendsms($numbers, $message, $config) {
    if (empty($config['api_user']) || empty($config['api_pass']) || empty($config['api_from'])) {
        smsadmin_log_error('ارسال پیامک', 'اطلاعات API ناقص است.');
        return ['status' => 'error', 'message' => __('اطلاعات API ناقص است.', 'smsadmin')];
    }

    try {
        $client = new SoapClient($config['api_url'], [
            'encoding' => 'UTF-8',
            'exceptions' => true,
            'trace' => true,
            'cache_wsdl' => WSDL_CACHE_NONE
        ]);
        $response = $client->sendsms([
            'user' => (int)$config['api_user'],
            'pass' => (string)$config['api_pass'],
            'to' => (array)$numbers,
            'from' => (string)$config['api_from'],
            'text' => (string)$message
        ]);

        error_log('smsadmin_api_sendsms response: ' . print_r($response, true));

        return !empty($response->id) ? 
            ['status' => 'success', 'message' => __('پیامک ارسال شد.', 'smsadmin')] : 
            ['status' => 'error', 'message' => __('خطا در ارسال پیامک.', 'smsadmin')];
    } catch (Exception $e) {
        smsadmin_log_error('ارسال پیامک', $e->getMessage());
        error_log('smsadmin_api_sendsms error: ' . $e->getMessage());
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}