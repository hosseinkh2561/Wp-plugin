<?php
defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');

function smsadmin_api_balance($config) {
    if (empty($config['api_user']) || empty($config['api_pass'])) {
        return ['status' => 'error', 'message' => __('نام کاربری یا رمز عبور API وارد نشده است.', 'smsadmin')];
    }

    try {
        $client = new SoapClient($config['api_url'], [
            'encoding' => 'UTF-8',
            'exceptions' => true,
            'trace' => true,
            'cache_wsdl' => WSDL_CACHE_NONE
        ]);
        $response = $client->balance([
            'user' => (string)$config['api_user'],
            'pass' => (string)$config['api_pass']
        ]);

        error_log('smsadmin_api_balance response: ' . print_r($response, true));

        if (is_string($response) && !empty($response)) {
            return ['status' => 'success', 'balance' => $response];
        } elseif (is_object($response) && !empty($response->total)) {
            return ['status' => 'success', 'balance' => $response->total];
        } elseif (is_array($response) && !empty($response['total'])) {
            return ['status' => 'success', 'balance' => $response['total']];
        } else {
            return ['status' => 'error', 'message' => __('پاسخ نامعتبر یا خالی از API', 'smsadmin')];
        }
    } catch (Exception $e) {
        smsadmin_log_error('بررسی اعتبار', $e->getMessage());
        error_log('smsadmin_api_balance error: ' . $e->getMessage());
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}