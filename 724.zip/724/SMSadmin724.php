<?php
/*
Plugin Name: SMSadmin 724
Description: افزونه حرفه‌ای ارسال پیامک با API smsadmin.ir
Version: 7.2.4
Author: xAI Team
Text Domain: smsadmin
Domain Path: /languages
*/

defined('ABSPATH') or die('دسترسی مستقیم مجاز نیست');
define('SMSADMIN_VERSION', '7.2.4');
define('SMSADMIN_DIR', plugin_dir_path(__FILE__));
define('SMSADMIN_URL', plugin_dir_url(__FILE__));

add_action('plugins_loaded', function() {
    load_plugin_textdomain('smsadmin', false, dirname(plugin_basename(__FILE__)) . '/languages/');
});

require_once SMSADMIN_DIR . 'includes/functions.php';
require_once SMSADMIN_DIR . 'includes/install.php';
require_once SMSADMIN_DIR . 'includes/config.php';
require_once SMSADMIN_DIR . 'includes/dashboard.php';
require_once SMSADMIN_DIR . 'includes/send.php';
require_once SMSADMIN_DIR . 'includes/groups.php';
require_once SMSADMIN_DIR . 'includes/reports.php';
require_once SMSADMIN_DIR . 'includes/settings.php';

add_action('admin_menu', function() {
    add_menu_page(
        __('SMSadmin 724', 'smsadmin'),
        __('SMSadmin 724', 'smsadmin'),
        'manage_options',
        'smsadmin',
        'smsadmin_dashboard_page',
        'dashicons-sms',
        10
    );
    add_submenu_page(
        'smsadmin',
        __('داشبورد', 'smsadmin'),
        __('داشبورد', 'smsadmin'),
        'manage_options',
        'smsadmin',
        'smsadmin_dashboard_page'
    );
    add_submenu_page(
        'smsadmin',
        __('پیکربندی API', 'smsadmin'),
        __('پیکربندی API', 'smsadmin'),
        'manage_options',
        'smsadmin-config',
        'smsadmin_config_page'
    );
    add_submenu_page(
        'smsadmin',
        __('ارسال پیامک', 'smsadmin'),
        __('ارسال پیامک', 'smsadmin'),
        'manage_options',
        'smsadmin-send',
        'smsadmin_send_page'
    );
    add_submenu_page(
        'smsadmin',
        __('گروه‌ها', 'smsadmin'),
        __('گروه‌ها', 'smsadmin'),
        'manage_options',
        'smsadmin-groups',
        'smsadmin_groups_page'
    );
    add_submenu_page(
        'smsadmin',
        __('گزارش‌ها', 'smsadmin'),
        __('گزارش‌ها', 'smsadmin'),
        'manage_options',
        'smsadmin-reports',
        'smsadmin_reports_page'
    );
    add_submenu_page(
        'smsadmin',
        __('تنظیمات پیشرفته', 'smsadmin'),
        __('تنظیمات پیشرفته', 'smsadmin'),
        'manage_options',
        'smsadmin-settings',
        'smsadmin_settings_page'
    );
});

add_action('admin_enqueue_scripts', function($hook) {
    if (strpos($hook, 'smsadmin') !== false) {
        wp_enqueue_style('smsadmin-admin', SMSADMIN_URL . 'assets/css/admin.css', [], SMSADMIN_VERSION);
        wp_enqueue_script('smsadmin-admin', SMSADMIN_URL . 'assets/js/admin.js', ['jquery'], SMSADMIN_VERSION, true);
    }
});

register_activation_hook(__FILE__, 'smsadmin_install');